using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace TerraStorage.Systems
{
    public class RecipeCacheSystem : ModSystem
    {
        /// <summary>
        /// Maps item type -> list of recipes that produce that item.
        /// </summary>
        public Dictionary<int, List<Recipe>> RecipesByResult { get; private set; } = new();

        public static RecipeCacheSystem Instance => ModContent.GetInstance<RecipeCacheSystem>();

        public override void PostAddRecipes()
        {
            BuildCache();
        }

        private void BuildCache()
        {
            RecipesByResult.Clear();

            for (int i = 0; i < Recipe.numRecipes; i++)
            {
                var recipe = Main.recipe[i];
                if (recipe == null || recipe.createItem == null || recipe.createItem.type <= 0)
                    continue;

                int resultType = recipe.createItem.type;
                if (!RecipesByResult.ContainsKey(resultType))
                    RecipesByResult[resultType] = new List<Recipe>();

                RecipesByResult[resultType].Add(recipe);
            }
        }

        /// <summary>
        /// Get all recipes that produce the given item type.
        /// </summary>
        public List<Recipe> GetRecipesFor(int itemType)
        {
            return RecipesByResult.TryGetValue(itemType, out var recipes) ? recipes : new List<Recipe>();
        }
    }
}
