using System;
using System.Collections.Generic;
using System.Linq;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using TerraStorage.Common;

namespace TerraStorage.Systems
{
    public class StorageWorldSystem : ModSystem
    {
        private Dictionary<Guid, DiskData> _allDiskData = new();
        private long _insertionCounter;

        /// <summary>
        /// Incremented on every insert or extract. UI can poll this to detect changes.
        /// </summary>
        public long StorageVersion { get; private set; }

        public static StorageWorldSystem Instance => ModContent.GetInstance<StorageWorldSystem>();

        /// <summary>
        /// Get or create disk data for a given ID and tier.
        /// </summary>
        public DiskData GetOrCreateDiskData(Guid diskId, DiskTier tier)
        {
            if (!_allDiskData.TryGetValue(diskId, out var data))
            {
                data = new DiskData
                {
                    DiskId = diskId,
                    Tier = tier,
                    Items = new List<StoredItemStack>()
                };
                _allDiskData[diskId] = data;
            }
            return data;
        }

        /// <summary>
        /// Get disk data by ID. Returns null if not found.
        /// </summary>
        public DiskData GetDiskData(Guid diskId)
        {
            return _allDiskData.TryGetValue(diskId, out var data) ? data : null;
        }

        /// <summary>
        /// Check if a disk ID exists in world data.
        /// </summary>
        public bool HasDiskData(Guid diskId) => _allDiskData.ContainsKey(diskId);

        /// <summary>
        /// Get all items across multiple disks, consolidated by type+prefix.
        /// </summary>
        public List<ConsolidatedItem> GetConsolidatedItems(IEnumerable<Guid> diskIds)
        {
            var consolidated = new Dictionary<(int type, int prefix), ConsolidatedItem>();

            foreach (var diskId in diskIds)
            {
                if (!_allDiskData.TryGetValue(diskId, out var disk))
                    continue;

                foreach (var stored in disk.Items)
                {
                    var key = (stored.ItemType, stored.PrefixId);
                    if (!consolidated.TryGetValue(key, out var entry))
                    {
                        entry = new ConsolidatedItem
                        {
                            ItemType = stored.ItemType,
                            PrefixId = stored.PrefixId,
                            TotalCount = 0,
                            SourceDisks = new List<Guid>()
                        };
                        consolidated[key] = entry;
                    }

                    entry.TotalCount += stored.Stack;
                    if (stored.InsertionOrder > entry.LatestInsertionOrder)
                        entry.LatestInsertionOrder = stored.InsertionOrder;
                    if (!entry.SourceDisks.Contains(diskId))
                        entry.SourceDisks.Add(diskId);
                }
            }

            return consolidated.Values.ToList();
        }

        /// <summary>
        /// Insert an item across the given disks (tries each until inserted).
        /// Returns leftover count.
        /// </summary>
        public int InsertItem(IEnumerable<Guid> diskIds, Item item)
        {
            if (item == null || item.IsAir)
                return 0;

            _insertionCounter++;
            StorageVersion++;
            int remaining = item.stack;

            foreach (var diskId in diskIds)
            {
                if (!_allDiskData.TryGetValue(diskId, out var disk))
                    continue;

                var tempItem = item.Clone();
                tempItem.stack = remaining;
                remaining = disk.InsertItem(tempItem, _insertionCounter);

                if (remaining <= 0)
                    return 0;
            }

            return remaining;
        }

        /// <summary>
        /// Extract an item from across multiple disks.
        /// </summary>
        public Item ExtractItem(IEnumerable<Guid> diskIds, int itemType, int count, int prefixId = -1)
        {
            int totalExtracted = 0;

            foreach (var diskId in diskIds)
            {
                if (!_allDiskData.TryGetValue(diskId, out var disk))
                    continue;

                int needed = count - totalExtracted;
                var extracted = disk.ExtractItem(itemType, needed, prefixId);
                totalExtracted += extracted.IsAir ? 0 : extracted.stack;

                if (totalExtracted >= count)
                    break;
            }

            if (totalExtracted == 0)
                return new Item();

            StorageVersion++;

            var result = new Item();
            result.SetDefaults(itemType);
            result.stack = totalExtracted;
            if (prefixId > 0)
                result.Prefix(prefixId);
            return result;
        }

        /// <summary>
        /// Count total of a given item across multiple disks.
        /// </summary>
        public int CountItem(IEnumerable<Guid> diskIds, int itemType, int prefixId = -1)
        {
            int total = 0;
            foreach (var diskId in diskIds)
            {
                if (_allDiskData.TryGetValue(diskId, out var disk))
                    total += disk.CountItem(itemType, prefixId);
            }
            return total;
        }

        /// <summary>
        /// Register a disk ID with a given tier (ensures data exists).
        /// </summary>
        public void RegisterDisk(Guid diskId, DiskTier tier)
        {
            GetOrCreateDiskData(diskId, tier);
        }

        /// <summary>
        /// Assign an existing disk's data to a new Guid (for disk restoration).
        /// </summary>
        public bool RestoreDisk(Guid targetDiskId, Guid sourceDiskId)
        {
            if (!_allDiskData.TryGetValue(sourceDiskId, out var data))
                return false;

            // Create a reference so both IDs point to same underlying data
            _allDiskData[targetDiskId] = data;
            data.DiskId = targetDiskId;
            return true;
        }

        public override void SaveWorldData(TagCompound tag)
        {
            var diskList = _allDiskData.Values.Select(d => d.Save()).ToList();
            tag["disks"] = diskList;
            tag["insertionCounter"] = _insertionCounter;
        }

        public override void LoadWorldData(TagCompound tag)
        {
            _allDiskData.Clear();
            _insertionCounter = tag.ContainsKey("insertionCounter") ? tag.GetLong("insertionCounter") : 0;

            if (tag.ContainsKey("disks"))
            {
                var diskTags = tag.GetList<TagCompound>("disks");
                foreach (var diskTag in diskTags)
                {
                    var data = DiskData.Load(diskTag);
                    _allDiskData[data.DiskId] = data;
                }
            }
        }

        public override void OnWorldUnload()
        {
            _allDiskData.Clear();
        }
    }

    public class ConsolidatedItem
    {
        public int ItemType { get; set; }
        public int PrefixId { get; set; }
        public int TotalCount { get; set; }
        public long LatestInsertionOrder { get; set; }
        public List<Guid> SourceDisks { get; set; } = new();
    }
}
