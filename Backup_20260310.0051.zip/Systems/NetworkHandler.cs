using System;
using System.Collections.Generic;
using System.IO;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TerraStorage.Common;
using TerraStorage.Content.Tiles;

namespace TerraStorage.Systems
{
    public enum PacketType : byte
    {
        SyncDiskInsert,
        SyncDiskRemove,
        DepositItem,
        WithdrawItem,
        CraftRequest,
        SyncStorageBlock
    }

    public static class NetworkHandler
    {
        public static void HandlePacket(Mod mod, BinaryReader reader, int whoAmI)
        {
            var type = (PacketType)reader.ReadByte();

            switch (type)
            {
                case PacketType.SyncDiskInsert:
                    HandleSyncDiskInsert(mod, reader, whoAmI);
                    break;
                case PacketType.SyncDiskRemove:
                    HandleSyncDiskRemove(mod, reader, whoAmI);
                    break;
                case PacketType.DepositItem:
                    HandleDepositItem(mod, reader, whoAmI);
                    break;
                case PacketType.WithdrawItem:
                    HandleWithdrawItem(mod, reader, whoAmI);
                    break;
                case PacketType.SyncStorageBlock:
                    HandleSyncStorageBlock(mod, reader, whoAmI);
                    break;
            }
        }

        public static void SendSyncDiskInsert(Mod mod, int entityId, int slot, Item diskItem)
        {
            if (Main.netMode == NetmodeID.SinglePlayer)
                return;

            var packet = mod.GetPacket();
            packet.Write((byte)PacketType.SyncDiskInsert);
            packet.Write(entityId);
            packet.Write(slot);
            Terraria.ModLoader.IO.ItemIO.Send(diskItem, packet, true);
            packet.Send();
        }

        public static void SendSyncDiskRemove(Mod mod, int entityId, int slot)
        {
            if (Main.netMode == NetmodeID.SinglePlayer)
                return;

            var packet = mod.GetPacket();
            packet.Write((byte)PacketType.SyncDiskRemove);
            packet.Write(entityId);
            packet.Write(slot);
            packet.Send();
        }

        public static void SendDepositItem(Mod mod, List<Guid> diskIds, Item item)
        {
            if (Main.netMode != NetmodeID.MultiplayerClient)
                return;

            var packet = mod.GetPacket();
            packet.Write((byte)PacketType.DepositItem);
            packet.Write(diskIds.Count);
            foreach (var id in diskIds)
                packet.Write(id.ToByteArray());
            Terraria.ModLoader.IO.ItemIO.Send(item, packet, true);
            packet.Send();
        }

        public static void SendWithdrawItem(Mod mod, List<Guid> diskIds, int itemType, int count, int prefix)
        {
            if (Main.netMode != NetmodeID.MultiplayerClient)
                return;

            var packet = mod.GetPacket();
            packet.Write((byte)PacketType.WithdrawItem);
            packet.Write(Main.myPlayer);
            packet.Write(diskIds.Count);
            foreach (var id in diskIds)
                packet.Write(id.ToByteArray());
            packet.Write(itemType);
            packet.Write(count);
            packet.Write(prefix);
            packet.Send();
        }

        private static void HandleSyncDiskInsert(Mod mod, BinaryReader reader, int whoAmI)
        {
            int entityId = reader.ReadInt32();
            int slot = reader.ReadInt32();
            var item = Terraria.ModLoader.IO.ItemIO.Receive(reader, true);

            if (Terraria.DataStructures.TileEntity.ByID.TryGetValue(entityId, out var entity)
                && entity is StorageBlockEntity sbe)
            {
                sbe.DiskSlots[slot] = item;
            }

            // Server relays to other clients
            if (Main.netMode == NetmodeID.Server)
            {
                var packet = mod.GetPacket();
                packet.Write((byte)PacketType.SyncDiskInsert);
                packet.Write(entityId);
                packet.Write(slot);
                Terraria.ModLoader.IO.ItemIO.Send(item, packet, true);
                packet.Send(-1, whoAmI);
            }
        }

        private static void HandleSyncDiskRemove(Mod mod, BinaryReader reader, int whoAmI)
        {
            int entityId = reader.ReadInt32();
            int slot = reader.ReadInt32();

            if (Terraria.DataStructures.TileEntity.ByID.TryGetValue(entityId, out var entity)
                && entity is StorageBlockEntity sbe)
            {
                sbe.DiskSlots[slot] = new Item();
                sbe.DiskSlots[slot].TurnToAir();
            }

            if (Main.netMode == NetmodeID.Server)
            {
                var packet = mod.GetPacket();
                packet.Write((byte)PacketType.SyncDiskRemove);
                packet.Write(entityId);
                packet.Write(slot);
                packet.Send(-1, whoAmI);
            }
        }

        private static void HandleDepositItem(Mod mod, BinaryReader reader, int whoAmI)
        {
            int count = reader.ReadInt32();
            var diskIds = new List<Guid>();
            for (int i = 0; i < count; i++)
                diskIds.Add(new Guid(reader.ReadBytes(16)));

            var item = Terraria.ModLoader.IO.ItemIO.Receive(reader, true);

            if (Main.netMode == NetmodeID.Server)
            {
                StorageWorldSystem.Instance.InsertItem(diskIds, item);
            }
        }

        private static void HandleWithdrawItem(Mod mod, BinaryReader reader, int whoAmI)
        {
            int playerIndex = reader.ReadInt32();
            int diskCount = reader.ReadInt32();
            var diskIds = new List<Guid>();
            for (int i = 0; i < diskCount; i++)
                diskIds.Add(new Guid(reader.ReadBytes(16)));

            int itemType = reader.ReadInt32();
            int count = reader.ReadInt32();
            int prefix = reader.ReadInt32();

            if (Main.netMode == NetmodeID.Server)
            {
                var extracted = StorageWorldSystem.Instance.ExtractItem(diskIds, itemType, count, prefix);
                if (!extracted.IsAir)
                {
                    // Give item to the requesting player
                    int itemIndex = Item.NewItem(
                        new Terraria.DataStructures.EntitySource_Misc("TerraStorage"),
                        (int)Main.player[playerIndex].position.X,
                        (int)Main.player[playerIndex].position.Y,
                        Main.player[playerIndex].width,
                        Main.player[playerIndex].height,
                        extracted.type, extracted.stack, false, extracted.prefix);
                    NetMessage.SendData(MessageID.SyncItem, -1, -1, null, itemIndex);
                }
            }
        }

        private static void HandleSyncStorageBlock(Mod mod, BinaryReader reader, int whoAmI)
        {
            int entityId = reader.ReadInt32();
            if (Terraria.DataStructures.TileEntity.ByID.TryGetValue(entityId, out var entity)
                && entity is StorageBlockEntity sbe)
            {
                for (int i = 0; i < StorageBlockEntity.DiskSlotCount; i++)
                {
                    sbe.DiskSlots[i] = Terraria.ModLoader.IO.ItemIO.Receive(reader, true);
                }
            }
        }
    }
}
