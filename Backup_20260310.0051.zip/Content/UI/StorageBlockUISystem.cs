using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.UI;
using TerraStorage.Content.Tiles;

namespace TerraStorage.Content.UI
{
    public class StorageBlockUISystem : ModSystem
    {
        private const float MaxInteractDistance = 15f; // tiles

        private UserInterface _userInterface;
        private StorageBlockUIState _uiState;
        private bool _isOpen;
        private Point16 _entityTilePos;

        public override void Load()
        {
            if (!Main.dedServ)
            {
                _userInterface = new UserInterface();
                _uiState = new StorageBlockUIState();
                _uiState.Activate();
            }
        }

        public void OpenStorageBlock(StorageBlockEntity entity)
        {
            if (Main.dedServ)
                return;

            _uiState.SetEntity(entity);
            _entityTilePos = entity.Position;
            _userInterface.SetState(_uiState);
            _isOpen = true;
            Main.playerInventory = true;
        }

        public void CloseStorageBlock()
        {
            _userInterface.SetState(null);
            _isOpen = false;
        }

        public override void PreUpdatePlayers()
        {
            // Block Terraria's inventory shift+click BEFORE Player.Update processes it
            if (_isOpen && !Main.dedServ)
            {
                bool shift = Main.keyState.IsKeyDown(Keys.LeftShift) || Main.keyState.IsKeyDown(Keys.RightShift);
                if (shift)
                {
                    for (int i = 0; i < 50; i++)
                    {
                        if (StorageBlockUIState.IsMouseOverInventorySlot(i))
                        {
                            Main.LocalPlayer.mouseInterface = true;
                            break;
                        }
                    }
                }
            }
        }

        public override void UpdateUI(GameTime gameTime)
        {
            if (_isOpen)
            {
                if (!Main.playerInventory)
                {
                    CloseStorageBlock();
                    return;
                }

                var playerTilePos = Main.LocalPlayer.Center / 16f;
                float dist = Vector2.Distance(playerTilePos, _entityTilePos.ToVector2());
                if (dist > MaxInteractDistance)
                {
                    CloseStorageBlock();
                    return;
                }

                _userInterface?.Update(gameTime);
            }
        }

        public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers)
        {
            int inventoryIndex = layers.FindIndex(layer => layer.Name.Equals("Vanilla: Inventory"));
            if (inventoryIndex != -1 && _isOpen)
            {
                // Block vanilla shift+click on inventory before it processes
                layers.Insert(inventoryIndex, new LegacyGameInterfaceLayer(
                    "TerraStorage: Shift Click Block",
                    delegate
                    {
                        bool shift = Main.keyState.IsKeyDown(Keys.LeftShift) || Main.keyState.IsKeyDown(Keys.RightShift);
                        if (shift && Main.mouseLeft && Main.mouseLeftRelease)
                        {
                            for (int i = 0; i < 50; i++)
                            {
                                if (StorageBlockUIState.IsMouseOverInventorySlot(i))
                                {
                                    Main.mouseLeftRelease = false;
                                    break;
                                }
                            }
                        }
                        return true;
                    },
                    InterfaceScaleType.UI));

                layers.Insert(inventoryIndex + 2, new LegacyGameInterfaceLayer(
                    "TerraStorage: Storage Block UI",
                    delegate
                    {
                        _userInterface.Draw(Main.spriteBatch, new GameTime());
                        return true;
                    },
                    InterfaceScaleType.UI));
            }
        }
    }
}
