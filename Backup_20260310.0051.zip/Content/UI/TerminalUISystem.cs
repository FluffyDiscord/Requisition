using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.UI;
using TerraStorage.Content.Tiles;

namespace TerraStorage.Content.UI
{
    public class TerminalUISystem : ModSystem
    {
        private const float MaxInteractDistance = 15f; // tiles

        private UserInterface _userInterface;
        private TerminalUIState _uiState;
        private bool _isOpen;
        private Point16 _entityTilePos;

        public bool IsTerminalOpen => _isOpen;

        public override void Load()
        {
            if (!Main.dedServ)
            {
                _userInterface = new UserInterface();
                _uiState = new TerminalUIState();
                _uiState.Activate();
            }
        }

        public void OpenTerminal(TerminalEntity entity)
        {
            if (Main.dedServ)
                return;

            _uiState.SetTerminal(entity);
            _entityTilePos = entity.Position;
            _userInterface.SetState(_uiState);
            _isOpen = true;
            Main.playerInventory = true;
        }

        public void CloseTerminal()
        {
            _userInterface.SetState(null);
            _isOpen = false;
        }

        public override void PreUpdatePlayers()
        {
            if (_isOpen && !Main.dedServ)
            {
                bool shift = Main.keyState.IsKeyDown(Keys.LeftShift) || Main.keyState.IsKeyDown(Keys.RightShift);
                if (shift)
                {
                    for (int i = 0; i < 50; i++)
                    {
                        if (StorageBlockUIState.IsMouseOverInventorySlot(i))
                        {
                            Main.LocalPlayer.mouseInterface = true;
                            break;
                        }
                    }
                }
            }
        }

        public override void UpdateUI(GameTime gameTime)
        {
            if (_isOpen)
            {
                if (!Main.playerInventory)
                {
                    CloseTerminal();
                    return;
                }

                var playerTilePos = Main.LocalPlayer.Center / 16f;
                float dist = Vector2.Distance(playerTilePos, _entityTilePos.ToVector2());
                if (dist > MaxInteractDistance)
                {
                    CloseTerminal();
                    return;
                }

                _userInterface?.Update(gameTime);
            }
        }

        public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers)
        {
            int inventoryIndex = layers.FindIndex(layer => layer.Name.Equals("Vanilla: Inventory"));
            if (inventoryIndex != -1 && _isOpen)
            {
                // Block vanilla shift+click on inventory before it processes
                layers.Insert(inventoryIndex, new LegacyGameInterfaceLayer(
                    "TerraStorage: Shift Click Block",
                    delegate
                    {
                        bool shift = Main.keyState.IsKeyDown(Keys.LeftShift) || Main.keyState.IsKeyDown(Keys.RightShift);
                        if (shift && Main.mouseLeft && Main.mouseLeftRelease)
                        {
                            for (int i = 0; i < 50; i++)
                            {
                                if (StorageBlockUIState.IsMouseOverInventorySlot(i))
                                {
                                    Main.mouseLeftRelease = false;
                                    break;
                                }
                            }
                        }
                        return true;
                    },
                    InterfaceScaleType.UI));

                layers.Insert(inventoryIndex + 2, new LegacyGameInterfaceLayer(
                    "TerraStorage: Terminal UI",
                    delegate
                    {
                        _userInterface.Draw(Main.spriteBatch, new GameTime());
                        return true;
                    },
                    InterfaceScaleType.UI));
            }
        }
    }
}
