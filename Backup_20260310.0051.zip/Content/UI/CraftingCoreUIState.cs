using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.GameContent.UI.Elements;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;
using TerraStorage.Content.Tiles;

namespace TerraStorage.Content.UI
{
    public class CraftingCoreUIState : UIState
    {
        private const int Columns = 10;
        private const int Rows = 4;
        private const int SlotSize = 48;
        private const int SlotPadding = 4;

        private UIPanel _panel;
        private CraftingCoreEntity _entity;

        private bool _prevMouseLeft;
        private bool _dragging;
        private Vector2 _dragOffset;

        public void SetEntity(CraftingCoreEntity entity)
        {
            _entity = entity;
        }

        public override void OnInitialize()
        {
            _panel = new UIPanel();
            _panel.Width.Set(Columns * (SlotSize + SlotPadding) + 28, 0f);
            _panel.Height.Set(Rows * (SlotSize + SlotPadding) + 80, 0f);
            _panel.HAlign = 0.5f;
            _panel.VAlign = 0.4f;
            _panel.SetPadding(10);
            Append(_panel);

            var title = new UIText("Crafting Core - Station Modules");
            title.HAlign = 0.5f;
            _panel.Append(title);

            var helpText = new UIText("Insert crafting station items (workbenches, anvils, etc.)", 0.7f);
            helpText.HAlign = 0.5f;
            helpText.Top.Set(22, 0f);
            _panel.Append(helpText);

            var closeBtn = new UITextPanel<string>("X", 0.7f);
            closeBtn.Width.Set(30, 0f);
            closeBtn.Height.Set(24, 0f);
            closeBtn.Left.Set(-30, 1f);
            closeBtn.Top.Set(-6, 0f);
            closeBtn.OnLeftClick += (evt, el) =>
                ModContent.GetInstance<CraftingCoreUISystem>().CloseCraftingCore();
            _panel.Append(closeBtn);
        }

        protected override void DrawSelf(SpriteBatch spriteBatch)
        {
            base.DrawSelf(spriteBatch);

            if (_entity == null || _panel == null)
                return;

            _entity.EnsureSlotsInitialized();
            var panelDims = _panel.GetInnerDimensions();
            float startX = panelDims.X + 4;
            float startY = panelDims.Y + 44;

            for (int i = 0; i < CraftingCoreEntity.StationSlotCount; i++)
            {
                int col = i % Columns;
                int row = i / Columns;
                var pos = new Vector2(startX + col * (SlotSize + SlotPadding), startY + row * (SlotSize + SlotPadding));

                var slotRect = new Rectangle((int)pos.X, (int)pos.Y, SlotSize, SlotSize);
                Utils.DrawInvBG(spriteBatch, slotRect, new Color(120, 90, 50) * 0.7f);

                var item = _entity.StationSlots[i];
                if (item != null && !item.IsAir)
                    DrawItemInSlot(spriteBatch, item, slotRect);

                if (slotRect.Contains(Main.MouseScreen.ToPoint()))
                {
                    Main.LocalPlayer.mouseInterface = true;
                    if (item != null && !item.IsAir)
                    {
                        Main.HoverItem = item.Clone();
                        Main.hoverItemName = item.Name;
                    }
                    else
                    {
                        Main.hoverItemName = "Empty Station Slot";
                    }
                }
            }
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            if (_entity == null || _panel == null)
                return;

            if (_panel.ContainsPoint(Main.MouseScreen))
                Main.LocalPlayer.mouseInterface = true;

            // Block Terraria's inventory handling when shift is held so we can intercept shift+click
            bool shift = Main.keyState.IsKeyDown(Keys.LeftShift) || Main.keyState.IsKeyDown(Keys.RightShift);
            if (shift && !_panel.ContainsPoint(Main.MouseScreen))
            {
                for (int i = 0; i < 50; i++)
                {
                    if (StorageBlockUIState.IsMouseOverInventorySlot(i))
                    {
                        Main.LocalPlayer.mouseInterface = true;
                        break;
                    }
                }
            }

            bool justClicked = Main.mouseLeft && !_prevMouseLeft;
            _prevMouseLeft = Main.mouseLeft;

            // Dragging
            if (_dragging)
            {
                if (!Main.mouseLeft)
                {
                    _dragging = false;
                }
                else
                {
                    _panel.Left.Set(Main.MouseScreen.X - _dragOffset.X, 0f);
                    _panel.Top.Set(Main.MouseScreen.Y - _dragOffset.Y, 0f);
                    Recalculate();
                }
                return;
            }

            if (justClicked)
            {
                if (_panel.ContainsPoint(Main.MouseScreen))
                {
                    var dims = _panel.GetDimensions();
                    if (Main.MouseScreen.Y < dims.Y + 26)
                    {
                        _dragging = true;
                        _panel.HAlign = 0f;
                        _panel.VAlign = 0f;
                        _panel.Left.Set(dims.X, 0f);
                        _panel.Top.Set(dims.Y, 0f);
                        _dragOffset = Main.MouseScreen - new Vector2(dims.X, dims.Y);
                        Recalculate();
                    }
                    else
                    {
                        HandleSlotClick(Main.MouseScreen, shift);
                    }
                }
                else if (shift)
                {
                    HandleInventoryShiftClick();
                }
            }
        }

        private void HandleSlotClick(Vector2 mousePos, bool shift)
        {
            if (_entity == null)
                return;

            _entity.EnsureSlotsInitialized();
            var panelDims = _panel.GetInnerDimensions();
            float startX = panelDims.X + 4;
            float startY = panelDims.Y + 44;

            for (int i = 0; i < CraftingCoreEntity.StationSlotCount; i++)
            {
                int col = i % Columns;
                int row = i / Columns;
                var slotRect = new Rectangle(
                    (int)(startX + col * (SlotSize + SlotPadding)),
                    (int)(startY + row * (SlotSize + SlotPadding)),
                    SlotSize, SlotSize);

                if (!slotRect.Contains(mousePos.ToPoint()))
                    continue;

                var cursorItem = Main.mouseItem;

                if (cursorItem != null && !cursorItem.IsAir)
                {
                    if (CraftingCoreEntity.IsValidStation(cursorItem) && _entity.StationSlots[i].IsAir)
                    {
                        _entity.StationSlots[i] = cursorItem.Clone();
                        _entity.StationSlots[i].stack = 1;
                        cursorItem.stack--;
                        if (cursorItem.stack <= 0)
                            Main.mouseItem.TurnToAir();
                        SoundEngine.PlaySound(SoundID.Grab);
                    }
                    else if (!CraftingCoreEntity.IsValidStation(cursorItem))
                    {
                        Main.NewText("Only crafting station items can be inserted here!", 255, 100, 100);
                    }
                }
                else if (!shift)
                {
                    if (!_entity.StationSlots[i].IsAir)
                    {
                        Main.mouseItem = _entity.StationSlots[i].Clone();
                        _entity.StationSlots[i].TurnToAir();
                        SoundEngine.PlaySound(SoundID.Grab);
                    }
                }
                else
                {
                    if (!_entity.StationSlots[i].IsAir)
                    {
                        var item = _entity.StationSlots[i].Clone();
                        item = Main.LocalPlayer.GetItem(Main.myPlayer, item, GetItemSettings.InventoryEntityToPlayerInventorySettings);
                        if (item.IsAir)
                            _entity.StationSlots[i].TurnToAir();
                        else
                            _entity.StationSlots[i] = item;
                        SoundEngine.PlaySound(SoundID.Grab);
                    }
                }
                return;
            }
        }

        private void HandleInventoryShiftClick()
        {
            if (_entity == null)
                return;

            var player = Main.LocalPlayer;
            for (int i = 0; i < 50; i++)
            {
                if (player.inventory[i].IsAir || !CraftingCoreEntity.IsValidStation(player.inventory[i]))
                    continue;

                if (!StorageBlockUIState.IsMouseOverInventorySlot(i))
                    continue;

                _entity.EnsureSlotsInitialized();
                for (int s = 0; s < CraftingCoreEntity.StationSlotCount; s++)
                {
                    if (_entity.StationSlots[s].IsAir)
                    {
                        _entity.StationSlots[s] = player.inventory[i].Clone();
                        _entity.StationSlots[s].stack = 1;
                        player.inventory[i].stack--;
                        if (player.inventory[i].stack <= 0)
                            player.inventory[i].TurnToAir();
                        SoundEngine.PlaySound(SoundID.Grab);
                        return;
                    }
                }
                break;
            }
        }

        private void DrawItemInSlot(SpriteBatch spriteBatch, Item item, Rectangle rect)
        {
            Main.instance.LoadItem(item.type);
            var texture = TextureAssets.Item[item.type].Value;
            var sourceRect = Main.itemAnimations[item.type] != null
                ? Main.itemAnimations[item.type].GetFrame(texture)
                : texture.Frame();

            float scale = 1f;
            float maxDim = System.Math.Max(sourceRect.Width, sourceRect.Height);
            if (maxDim > 36) scale = 36f / maxDim;

            spriteBatch.Draw(texture,
                new Vector2(rect.X + rect.Width / 2, rect.Y + rect.Height / 2),
                sourceRect, Color.White, 0f,
                new Vector2(sourceRect.Width / 2, sourceRect.Height / 2),
                scale, SpriteEffects.None, 0f);
        }
    }
}
