using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.GameContent.UI.Elements;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;
using TerraStorage.Content.Items;
using TerraStorage.Content.Tiles;

namespace TerraStorage.Content.UI
{
    public class StorageBlockUIState : UIState
    {
        private const int Columns = 10;
        private const int Rows = 4;
        private const int SlotSize = 48;
        private const int SlotPadding = 4;

        private UIPanel _panel;
        private StorageBlockEntity _entity;

        private bool _prevMouseLeft;
        private bool _dragging;
        private Vector2 _dragOffset;

        public void SetEntity(StorageBlockEntity entity)
        {
            _entity = entity;
        }

        public override void OnInitialize()
        {
            _panel = new UIPanel();
            _panel.Width.Set(Columns * (SlotSize + SlotPadding) + 28, 0f);
            _panel.Height.Set(Rows * (SlotSize + SlotPadding) + 60, 0f);
            _panel.HAlign = 0.5f;
            _panel.VAlign = 0.4f;
            _panel.SetPadding(10);
            Append(_panel);

            var title = new UIText("Drive Bay");
            title.HAlign = 0.5f;
            _panel.Append(title);

            var closeBtn = new UITextPanel<string>("X", 0.7f);
            closeBtn.Width.Set(30, 0f);
            closeBtn.Height.Set(24, 0f);
            closeBtn.Left.Set(-30, 1f);
            closeBtn.Top.Set(-6, 0f);
            closeBtn.OnLeftClick += (evt, el) =>
                ModContent.GetInstance<StorageBlockUISystem>().CloseStorageBlock();
            _panel.Append(closeBtn);
        }

        protected override void DrawSelf(SpriteBatch spriteBatch)
        {
            base.DrawSelf(spriteBatch);

            if (_entity == null || _panel == null)
                return;

            _entity.EnsureSlotsInitialized();
            var panelDims = _panel.GetInnerDimensions();
            float startX = panelDims.X + 4;
            float startY = panelDims.Y + 28;

            for (int i = 0; i < StorageBlockEntity.DiskSlotCount; i++)
            {
                int col = i % Columns;
                int row = i / Columns;
                var pos = new Vector2(startX + col * (SlotSize + SlotPadding), startY + row * (SlotSize + SlotPadding));

                var slotRect = new Rectangle((int)pos.X, (int)pos.Y, SlotSize, SlotSize);
                Utils.DrawInvBG(spriteBatch, slotRect, new Color(63, 82, 151) * 0.7f);

                var item = _entity.DiskSlots[i];
                if (item != null && !item.IsAir)
                    DrawItemInSlot(spriteBatch, item, slotRect);

                if (slotRect.Contains(Main.MouseScreen.ToPoint()))
                {
                    Main.LocalPlayer.mouseInterface = true;
                    if (item != null && !item.IsAir)
                    {
                        Main.HoverItem = item.Clone();
                        Main.hoverItemName = item.Name;
                    }
                    else
                    {
                        Main.hoverItemName = "Empty Disk Slot";
                    }
                }
            }
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            if (_entity == null || _panel == null)
                return;

            if (_panel.ContainsPoint(Main.MouseScreen))
                Main.LocalPlayer.mouseInterface = true;

            // Block Terraria's inventory handling when shift is held so we can intercept shift+click
            bool shift = Main.keyState.IsKeyDown(Keys.LeftShift) || Main.keyState.IsKeyDown(Keys.RightShift);
            if (shift && !_panel.ContainsPoint(Main.MouseScreen))
            {
                for (int i = 0; i < 50; i++)
                {
                    if (IsMouseOverInventorySlot(i))
                    {
                        Main.LocalPlayer.mouseInterface = true;
                        break;
                    }
                }
            }

            bool justClicked = Main.mouseLeft && !_prevMouseLeft;
            _prevMouseLeft = Main.mouseLeft;

            // Dragging
            if (_dragging)
            {
                if (!Main.mouseLeft)
                {
                    _dragging = false;
                }
                else
                {
                    _panel.Left.Set(Main.MouseScreen.X - _dragOffset.X, 0f);
                    _panel.Top.Set(Main.MouseScreen.Y - _dragOffset.Y, 0f);
                    Recalculate();
                }
                return;
            }

            if (justClicked)
            {
                if (_panel.ContainsPoint(Main.MouseScreen))
                {
                    // Check if clicking title bar area for drag
                    var dims = _panel.GetDimensions();
                    if (Main.MouseScreen.Y < dims.Y + 26)
                    {
                        _dragging = true;
                        _panel.HAlign = 0f;
                        _panel.VAlign = 0f;
                        _panel.Left.Set(dims.X, 0f);
                        _panel.Top.Set(dims.Y, 0f);
                        _dragOffset = Main.MouseScreen - new Vector2(dims.X, dims.Y);
                        Recalculate();
                    }
                    else
                    {
                        HandleSlotClick(Main.MouseScreen, shift);
                    }
                }
                else if (shift)
                {
                    HandleInventoryShiftClick();
                }
            }
        }

        private void HandleSlotClick(Vector2 mousePos, bool shift)
        {
            if (_entity == null)
                return;

            _entity.EnsureSlotsInitialized();
            var panelDims = _panel.GetInnerDimensions();
            float startX = panelDims.X + 4;
            float startY = panelDims.Y + 28;

            for (int i = 0; i < StorageBlockEntity.DiskSlotCount; i++)
            {
                int col = i % Columns;
                int row = i / Columns;
                var slotRect = new Rectangle(
                    (int)(startX + col * (SlotSize + SlotPadding)),
                    (int)(startY + row * (SlotSize + SlotPadding)),
                    SlotSize, SlotSize);

                if (!slotRect.Contains(mousePos.ToPoint()))
                    continue;

                var cursorItem = Main.mouseItem;

                if (cursorItem != null && !cursorItem.IsAir)
                {
                    if (cursorItem.ModItem is StorageDiskBase && _entity.DiskSlots[i].IsAir)
                    {
                        _entity.DiskSlots[i] = cursorItem.Clone();
                        Main.mouseItem.TurnToAir();
                        SoundEngine.PlaySound(SoundID.Grab);
                    }
                }
                else if (!shift)
                {
                    if (!_entity.DiskSlots[i].IsAir)
                    {
                        Main.mouseItem = _entity.DiskSlots[i].Clone();
                        _entity.DiskSlots[i].TurnToAir();
                        SoundEngine.PlaySound(SoundID.Grab);
                    }
                }
                else
                {
                    if (!_entity.DiskSlots[i].IsAir)
                    {
                        var item = _entity.DiskSlots[i].Clone();
                        item = Main.LocalPlayer.GetItem(Main.myPlayer, item, GetItemSettings.InventoryEntityToPlayerInventorySettings);
                        if (item.IsAir)
                            _entity.DiskSlots[i].TurnToAir();
                        else
                            _entity.DiskSlots[i] = item;
                        SoundEngine.PlaySound(SoundID.Grab);
                    }
                }
                return;
            }
        }

        private void HandleInventoryShiftClick()
        {
            if (_entity == null)
                return;

            var player = Main.LocalPlayer;
            for (int i = 0; i < 50; i++)
            {
                if (player.inventory[i].IsAir || player.inventory[i].ModItem is not StorageDiskBase)
                    continue;

                if (!IsMouseOverInventorySlot(i))
                    continue;

                _entity.EnsureSlotsInitialized();
                for (int s = 0; s < StorageBlockEntity.DiskSlotCount; s++)
                {
                    if (_entity.DiskSlots[s].IsAir)
                    {
                        _entity.DiskSlots[s] = player.inventory[i].Clone();
                        player.inventory[i].TurnToAir();
                        SoundEngine.PlaySound(SoundID.Grab);
                        return;
                    }
                }
                break;
            }
        }

        public static bool IsMouseOverInventorySlot(int slot)
        {
            // Vanilla uses 0.85f scale for all 50 inventory slots (10 cols x 5 rows)
            // Hit rect uses InventoryBack texture size (52x52) * scale
            const float scale = 0.85f;
            int col = slot % 10;
            int row = slot / 10;
            int x = (int)(20f + col * 56 * scale);
            int y = (int)(20f + row * 56 * scale);
            int size = (int)(52 * scale);
            return new Rectangle(x, y, size, size).Contains(Main.MouseScreen.ToPoint());
        }

        private void DrawItemInSlot(SpriteBatch spriteBatch, Item item, Rectangle rect)
        {
            Main.instance.LoadItem(item.type);
            var texture = TextureAssets.Item[item.type].Value;
            var sourceRect = Main.itemAnimations[item.type] != null
                ? Main.itemAnimations[item.type].GetFrame(texture)
                : texture.Frame();

            float scale = 1f;
            float maxDim = System.Math.Max(sourceRect.Width, sourceRect.Height);
            if (maxDim > 36) scale = 36f / maxDim;

            spriteBatch.Draw(texture,
                new Vector2(rect.X + rect.Width / 2, rect.Y + rect.Height / 2),
                sourceRect, Color.White, 0f,
                new Vector2(sourceRect.Width / 2, sourceRect.Height / 2),
                scale, SpriteEffects.None, 0f);
        }
    }
}
