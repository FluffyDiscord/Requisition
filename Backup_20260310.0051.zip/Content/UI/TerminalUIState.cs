using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.GameContent.UI.Elements;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;
using TerraStorage.Content.Tiles;
using TerraStorage.Content.UI.Elements;
using TerraStorage.Helpers;
using TerraStorage.Systems;

namespace TerraStorage.Content.UI
{
    public enum SortMode
    {
        ID,
        Name,
        Value,
        DamageDefense,
        Quantity,
        StackCount,
        RecentlyAdded
    }

    public class TerminalUIState : UIState
    {
        private const float MinWidth = 650f;
        private const float MaxWidth = 1200f;
        private const float MinHeight = 300f;
        private const float ResizeHandleSize = 16f;

        // Header layout constants
        private const float TabsY = 0f;
        private const float TabsHeight = 25f;
        private const float SearchBarY = 35f;
        private const float SearchBarHeight = 30f;
        private const float FilterBarY = 70f;
        private const float FilterBarHeight = 26f;
        private const float SortBarY = 96f;
        private const float SortBarHeight = 26f;
        private const float ContentY = 122f;
        private const float FooterHeight = 55f;

        private UIPanel _mainPanel;
        private StorageSearchBar _searchBar;
        private UICategoryFilterBar _filterBar;
        private UIItemGrid _itemGrid;
        private UICraftingPanel _craftingPanel;
        private UIScrollbar _scrollbar;
        private UIText _statusText;

        private TerminalEntity _terminal;
        private List<Guid> _connectedDiskIds = new();
        private HashSet<int> _availableStations = new();
        private List<ConsolidatedItem> _cachedItems = new();

        // Tabs
        private UITextPanel<string> _storageTab;
        private UITextPanel<string> _craftingTab;
        private bool _showCrafting;

        // Sorting
        private SortMode _currentSort = SortMode.ID;
        private bool _sortAscending = true;
        private UISortBar _sortBar;

        // Footer elements (need references for repositioning on resize)
        private UITextPanel<string> _depositAllBtn;

        // Change detection
        private long _lastStorageVersion = -1;

        // Dragging
        private bool _prevMouseLeft;
        private bool _dragging;
        private Vector2 _dragOffset;

        // Resizing
        private bool _resizing;
        private Vector2 _resizeStart;
        private float _resizeOrigWidth;
        private float _resizeOrigHeight;

        // Current panel dimensions
        private float _panelWidth = 780f;
        private float _panelHeight;

        // Item property caches for sorting
        private static readonly Dictionary<int, string> _nameCache = new();
        private static readonly Dictionary<int, int> _valueCache = new();
        private static readonly Dictionary<int, int> _damageDefenseCache = new();
        private static readonly Dictionary<int, int> _maxStackCache = new();

        public void SetTerminal(TerminalEntity terminal)
        {
            _terminal = terminal;
            RefreshDiskConnections();
            RefreshItems();
        }

        public override void OnInitialize()
        {
            _panelHeight = Math.Max(400, Main.screenHeight - 340);

            _mainPanel = new UIPanel();
            _mainPanel.Width.Set(_panelWidth, 0f);
            _mainPanel.Height.Set(_panelHeight, 0f);
            _mainPanel.Left.Set(14, 0f);
            _mainPanel.Top.Set(310, 0f);
            _mainPanel.SetPadding(12);
            Append(_mainPanel);

            // Close button
            var closeBtn = new UITextPanel<string>("X", 0.7f);
            closeBtn.Width.Set(30, 0f);
            closeBtn.Height.Set(24, 0f);
            closeBtn.Left.Set(-30, 1f);
            closeBtn.Top.Set(-6, 0f);
            closeBtn.OnLeftClick += (evt, el) =>
                ModContent.GetInstance<TerminalUISystem>().CloseTerminal();
            _mainPanel.Append(closeBtn);

            // Tabs
            _storageTab = new UITextPanel<string>("Storage", 0.9f, false);
            _storageTab.Width.Set(100, 0f);
            _storageTab.Height.Set(TabsHeight, 0f);
            _storageTab.Left.Set(10, 0f);
            _storageTab.Top.Set(TabsY, 0f);
            _storageTab.OnLeftClick += (evt, el) => SwitchTab(false);
            _mainPanel.Append(_storageTab);

            _craftingTab = new UITextPanel<string>("Crafting", 0.9f, false);
            _craftingTab.Width.Set(100, 0f);
            _craftingTab.Height.Set(TabsHeight, 0f);
            _craftingTab.Left.Set(120, 0f);
            _craftingTab.Top.Set(TabsY, 0f);
            _craftingTab.OnLeftClick += (evt, el) => SwitchTab(true);
            _mainPanel.Append(_craftingTab);

            // Search bar
            _searchBar = new StorageSearchBar();
            _searchBar.Width.Set(-30, 1f);
            _searchBar.Height.Set(SearchBarHeight, 0f);
            _searchBar.Left.Set(10, 0f);
            _searchBar.Top.Set(SearchBarY, 0f);
            _searchBar.OnTextChanged += OnSearchChanged;
            _mainPanel.Append(_searchBar);

            // Category filter bar
            _filterBar = new UICategoryFilterBar();
            _filterBar.Width.Set(-30, 1f);
            _filterBar.Height.Set(FilterBarHeight, 0f);
            _filterBar.Left.Set(10, 0f);
            _filterBar.Top.Set(FilterBarY, 0f);
            _filterBar.OnFilterChanged += () =>
            {
                if (_showCrafting)
                    _craftingPanel.RefreshFilteredRecipes();
                else
                    FilterAndDisplayItems();
            };
            _mainPanel.Append(_filterBar);

            // Sort bar (below filters)
            _sortBar = new UISortBar();
            _sortBar.Width.Set(-30, 1f);
            _sortBar.Height.Set(SortBarHeight, 0f);
            _sortBar.Left.Set(10, 0f);
            _sortBar.Top.Set(SortBarY, 0f);
            _sortBar.OnSortChanged += () =>
            {
                _currentSort = (SortMode)_sortBar.Selected;
                _sortAscending = _sortBar.Ascending;
                FilterAndDisplayItems();
            };
            _mainPanel.Append(_sortBar);

            // Content area
            float contentHeight = _panelHeight - ContentY - FooterHeight;

            // Scrollbar
            _scrollbar = new UIScrollbar();
            _scrollbar.Height.Set(contentHeight, 0f);
            _scrollbar.Left.Set(-25, 1f);
            _scrollbar.Top.Set(ContentY, 0f);
            _mainPanel.Append(_scrollbar);

            // Item grid
            _itemGrid = new UIItemGrid();
            _itemGrid.Width.Set(-50, 1f);
            _itemGrid.Height.Set(contentHeight, 0f);
            _itemGrid.Left.Set(10, 0f);
            _itemGrid.Top.Set(ContentY, 0f);
            _itemGrid.SetScrollbar(_scrollbar);
            _itemGrid.OnItemClicked += OnItemClicked;
            _itemGrid.OnItemRightClicked += OnItemRightClicked;
            _mainPanel.Append(_itemGrid);

            // Crafting panel (initially hidden)
            _craftingPanel = new UICraftingPanel();
            _craftingPanel.Width.Set(-50, 1f);
            _craftingPanel.Height.Set(contentHeight, 0f);
            _craftingPanel.Left.Set(10, 0f);
            _craftingPanel.Top.Set(ContentY, 0f);

            // Footer
            float footerY = _panelHeight - FooterHeight;

            _depositAllBtn = new UITextPanel<string>("Deposit All", 0.8f);
            _depositAllBtn.Width.Set(130, 0f);
            _depositAllBtn.Height.Set(30, 0f);
            _depositAllBtn.Left.Set(10, 0f);
            _depositAllBtn.Top.Set(footerY - 5, 0f);
            _depositAllBtn.OnLeftClick += OnDepositAll;
            _mainPanel.Append(_depositAllBtn);

            _statusText = new UIText("", 0.8f);
            _statusText.Left.Set(-310, 1f);
            _statusText.Top.Set(footerY, 0f);
            _mainPanel.Append(_statusText);

            UpdateTabVisuals();
            RecalculateColumns();
        }

        private void SwitchTab(bool crafting)
        {
            _showCrafting = crafting;
            UpdateTabVisuals();

            if (_showCrafting)
            {
                _mainPanel.RemoveChild(_itemGrid);
                _mainPanel.RemoveChild(_scrollbar);
                _mainPanel.RemoveChild(_depositAllBtn);
                _mainPanel.Append(_craftingPanel);
                RefreshDiskConnections();
                _craftingPanel.SetCategoryFilter(_filterBar);
                _craftingPanel.SetSearchText(_searchBar.SearchText);
                _craftingPanel.SetAvailableStations(_availableStations);
                _craftingPanel.SetDiskIds(_connectedDiskIds);
            }
            else
            {
                _mainPanel.RemoveChild(_craftingPanel);
                _mainPanel.Append(_itemGrid);
                _mainPanel.Append(_scrollbar);
                _mainPanel.Append(_depositAllBtn);
                RefreshItems();
            }
        }

        private void UpdateTabVisuals()
        {
            _storageTab.BackgroundColor = _showCrafting
                ? new Color(63, 82, 151) * 0.7f
                : new Color(73, 94, 171);
            _craftingTab.BackgroundColor = _showCrafting
                ? new Color(73, 94, 171)
                : new Color(63, 82, 151) * 0.7f;
        }

        private void RefreshDiskConnections()
        {
            if (_terminal != null)
            {
                _connectedDiskIds = _terminal.GetConnectedDiskIds();
                _availableStations = _terminal.GetAvailableStations();
            }
            else
            {
                _connectedDiskIds.Clear();
                _availableStations.Clear();
            }
        }

        private void RefreshItems()
        {
            if (_connectedDiskIds.Count == 0)
            {
                _cachedItems.Clear();
                _itemGrid?.SetItems(new List<ConsolidatedItem>());
                _statusText?.SetText("No drive bays connected");
                return;
            }

            _cachedItems = StorageWorldSystem.Instance.GetConsolidatedItems(_connectedDiskIds);
            FilterAndDisplayItems();
        }

        private void FilterAndDisplayItems()
        {
            var items = new List<ConsolidatedItem>(_cachedItems);
            var search = _searchBar?.SearchText ?? "";

            if (!string.IsNullOrEmpty(search))
            {
                items = items.Where(ci =>
                {
                    string name = GetCachedName(ci.ItemType);
                    return name.Contains(search, StringComparison.OrdinalIgnoreCase);
                }).ToList();
            }

            // Apply category filter
            if (_filterBar != null)
                items = items.Where(ci => _filterBar.PassesFilter(ci.ItemType)).ToList();

            // Apply sort
            SortItems(items);

            _itemGrid?.SetItems(items);
            _statusText?.SetText($"{items.Count} types | {_connectedDiskIds.Count} disks | {_availableStations.Count} stations");
        }

        private void SortItems(List<ConsolidatedItem> items)
        {
            int dir = _sortAscending ? 1 : -1;
            items.Sort((a, b) =>
            {
                int result = _currentSort switch
                {
                    SortMode.ID => a.ItemType.CompareTo(b.ItemType),
                    SortMode.Name => string.Compare(GetCachedName(a.ItemType), GetCachedName(b.ItemType), StringComparison.OrdinalIgnoreCase),
                    SortMode.Value => GetCachedValue(a.ItemType).CompareTo(GetCachedValue(b.ItemType)),
                    SortMode.DamageDefense => GetCachedDamageDefense(a.ItemType).CompareTo(GetCachedDamageDefense(b.ItemType)),
                    SortMode.Quantity => a.TotalCount.CompareTo(b.TotalCount),
                    SortMode.StackCount => GetCachedMaxStack(a.ItemType).CompareTo(GetCachedMaxStack(b.ItemType)),
                    SortMode.RecentlyAdded => a.LatestInsertionOrder.CompareTo(b.LatestInsertionOrder),
                    _ => a.ItemType.CompareTo(b.ItemType)
                };
                return result * dir;
            });
        }

        private static string GetCachedName(int itemType)
        {
            if (!_nameCache.TryGetValue(itemType, out var name))
            {
                var item = new Item();
                item.SetDefaults(itemType);
                name = item.Name;
                _nameCache[itemType] = name;
            }
            return name;
        }

        private static int GetCachedValue(int itemType)
        {
            if (!_valueCache.TryGetValue(itemType, out var value))
            {
                var item = new Item();
                item.SetDefaults(itemType);
                value = item.value;
                _valueCache[itemType] = value;
            }
            return value;
        }

        private static int GetCachedDamageDefense(int itemType)
        {
            if (!_damageDefenseCache.TryGetValue(itemType, out var val))
            {
                var item = new Item();
                item.SetDefaults(itemType);
                val = item.damage > 0 ? item.damage : item.defense;
                _damageDefenseCache[itemType] = val;
            }
            return val;
        }

        private static int GetCachedMaxStack(int itemType)
        {
            if (!_maxStackCache.TryGetValue(itemType, out var val))
            {
                var item = new Item();
                item.SetDefaults(itemType);
                val = item.maxStack;
                _maxStackCache[itemType] = val;
            }
            return val;
        }

        private void OnSearchChanged(string text)
        {
            if (_showCrafting)
                _craftingPanel.SetSearchText(text);
            else
                FilterAndDisplayItems();
        }

        private void OnItemClicked(ConsolidatedItem item)
        {
            if (item == null || _connectedDiskIds.Count == 0)
                return;

            bool shift = Main.keyState.IsKeyDown(Keys.LeftShift) || Main.keyState.IsKeyDown(Keys.RightShift);

            if (Main.mouseItem != null && !Main.mouseItem.IsAir)
            {
                DepositCursorItem();
                return;
            }

            var tempItem = new Item();
            tempItem.SetDefaults(item.ItemType);
            int maxStack = tempItem.maxStack;
            int withdrawCount = Math.Min(maxStack, item.TotalCount);

            var extracted = StorageWorldSystem.Instance.ExtractItem(
                _connectedDiskIds, item.ItemType, withdrawCount, item.PrefixId);

            if (!extracted.IsAir)
            {
                if (shift)
                {
                    var player = Main.LocalPlayer;
                    extracted = player.GetItem(player.whoAmI, extracted, GetItemSettings.InventoryEntityToPlayerInventorySettings);
                    if (!extracted.IsAir)
                        StorageWorldSystem.Instance.InsertItem(_connectedDiskIds, extracted);
                }
                else
                {
                    if (Main.mouseItem.IsAir)
                        Main.mouseItem = extracted;
                    else
                        StorageWorldSystem.Instance.InsertItem(_connectedDiskIds, extracted);
                }
                SoundEngine.PlaySound(SoundID.Grab);
            }

            RefreshItems();
        }

        private void OnItemRightClicked(ConsolidatedItem item)
        {
            if (item == null || _connectedDiskIds.Count == 0)
                return;

            var extracted = StorageWorldSystem.Instance.ExtractItem(
                _connectedDiskIds, item.ItemType, 1, item.PrefixId);

            if (!extracted.IsAir)
            {
                if (Main.mouseItem.IsAir)
                {
                    Main.mouseItem = extracted;
                }
                else if (Main.mouseItem.type == extracted.type && Main.mouseItem.prefix == extracted.prefix
                    && Main.mouseItem.stack < Main.mouseItem.maxStack)
                {
                    Main.mouseItem.stack += extracted.stack;
                }
                else
                {
                    StorageWorldSystem.Instance.InsertItem(_connectedDiskIds, extracted);
                }
                SoundEngine.PlaySound(SoundID.Grab);
            }

            RefreshItems();
        }

        private void DepositCursorItem()
        {
            if (Main.mouseItem == null || Main.mouseItem.IsAir || _connectedDiskIds.Count == 0)
                return;

            int leftover = StorageWorldSystem.Instance.InsertItem(_connectedDiskIds, Main.mouseItem);
            if (leftover <= 0)
                Main.mouseItem.TurnToAir();
            else
                Main.mouseItem.stack = leftover;

            SoundEngine.PlaySound(SoundID.Grab);
            RefreshItems();
        }

        private void OnDepositAll(UIMouseEvent evt, UIElement element)
        {
            if (_connectedDiskIds.Count == 0)
                return;

            var player = Main.LocalPlayer;
            for (int i = 10; i < 50; i++)
            {
                if (player.inventory[i].IsAir || player.inventory[i].favorited)
                    continue;

                int leftover = StorageWorldSystem.Instance.InsertItem(_connectedDiskIds, player.inventory[i]);
                if (leftover <= 0)
                    player.inventory[i].TurnToAir();
                else
                    player.inventory[i].stack = leftover;
            }

            SoundEngine.PlaySound(SoundID.Grab);
            RefreshItems();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            if (_mainPanel.ContainsPoint(Main.MouseScreen))
            {
                Main.LocalPlayer.mouseInterface = true;
                PlayerInput.LockVanillaMouseScroll("TerraStorage");
            }

            // Block Terraria's inventory handling when shift is held so we can intercept shift+click
            bool shift = Main.keyState.IsKeyDown(Keys.LeftShift) || Main.keyState.IsKeyDown(Keys.RightShift);
            if (shift && !_mainPanel.ContainsPoint(Main.MouseScreen))
            {
                for (int i = 0; i < 50; i++)
                {
                    if (StorageBlockUIState.IsMouseOverInventorySlot(i))
                    {
                        Main.LocalPlayer.mouseInterface = true;
                        break;
                    }
                }
            }

            bool justClicked = Main.mouseLeft && !_prevMouseLeft;
            _prevMouseLeft = Main.mouseLeft;

            // Resizing
            if (_resizing)
            {
                if (!Main.mouseLeft)
                {
                    _resizing = false;
                }
                else
                {
                    float newWidth = Math.Clamp(_resizeOrigWidth + (Main.MouseScreen.X - _resizeStart.X), MinWidth, MaxWidth);
                    float maxH = Main.screenHeight - _mainPanel.GetDimensions().Y - 10;
                    float newHeight = Math.Clamp(_resizeOrigHeight + (Main.MouseScreen.Y - _resizeStart.Y), MinHeight, maxH);

                    _panelWidth = newWidth;
                    _panelHeight = newHeight;
                    _mainPanel.Width.Set(_panelWidth, 0f);
                    _mainPanel.Height.Set(_panelHeight, 0f);
                    RecalculateLayout();
                    Recalculate();
                }
                return;
            }

            // Dragging
            if (_dragging)
            {
                if (!Main.mouseLeft)
                {
                    _dragging = false;
                }
                else
                {
                    _mainPanel.Left.Set(Main.MouseScreen.X - _dragOffset.X, 0f);
                    _mainPanel.Top.Set(Main.MouseScreen.Y - _dragOffset.Y, 0f);
                    Recalculate();
                }
                return;
            }

            if (justClicked)
            {
                if (_mainPanel.ContainsPoint(Main.MouseScreen))
                {
                    var dims = _mainPanel.GetDimensions();

                    // Check resize handle (bottom-right corner)
                    if (Main.MouseScreen.X > dims.X + dims.Width - ResizeHandleSize
                        && Main.MouseScreen.Y > dims.Y + dims.Height - ResizeHandleSize)
                    {
                        _resizing = true;
                        _resizeStart = Main.MouseScreen;
                        _resizeOrigWidth = _panelWidth;
                        _resizeOrigHeight = _panelHeight;
                        return;
                    }

                    // Check drag area (top edge of panel padding)
                    if (Main.MouseScreen.Y < dims.Y + 12)
                    {
                        _dragging = true;
                        _dragOffset = Main.MouseScreen - new Vector2(dims.X, dims.Y);
                        Recalculate();
                    }
                    else if (!_showCrafting && Main.mouseItem != null && !Main.mouseItem.IsAir
                        && !_itemGrid.ContainsPoint(Main.MouseScreen))
                    {
                        DepositCursorItem();
                    }
                }
                else if (shift)
                {
                    HandleInventoryShiftClick();
                }
            }

            // Refresh disk connections periodically (new drive bays placed is infrequent)
            if (Main.GameUpdateCount % 120 == 0)
                RefreshDiskConnections();

            // Refresh storage tab when contents change
            if (!_showCrafting)
            {
                long currentVersion = StorageWorldSystem.Instance.StorageVersion;
                if (currentVersion != _lastStorageVersion)
                {
                    _lastStorageVersion = currentVersion;
                    RefreshItems();
                }
            }
        }

        private void RecalculateLayout()
        {
            float contentHeight = _panelHeight - ContentY - FooterHeight;
            float footerY = _panelHeight - FooterHeight;

            _scrollbar.Height.Set(contentHeight, 0f);
            _itemGrid.Height.Set(contentHeight, 0f);
            _craftingPanel.Height.Set(contentHeight, 0f);
            _depositAllBtn.Top.Set(footerY - 5, 0f);
            _statusText.Top.Set(footerY, 0f);

            RecalculateColumns();
        }

        private void RecalculateColumns()
        {
            float gridWidth = _panelWidth - 74; // padding + scrollbar + margins
            int columns = Math.Max(1, (int)(gridWidth / 48));
            _itemGrid.SetColumns(columns);
        }

        protected override void DrawSelf(SpriteBatch spriteBatch)
        {
            base.DrawSelf(spriteBatch);

            // Draw resize grip in bottom-right corner
            var dims = _mainPanel.GetDimensions();
            float gripX = dims.X + dims.Width - ResizeHandleSize;
            float gripY = dims.Y + dims.Height - ResizeHandleSize;

            for (int i = 0; i < 3; i++)
            {
                float offset = 4 + i * 4;
                var start = new Vector2(gripX + offset, gripY + ResizeHandleSize - 2);
                var end = new Vector2(gripX + ResizeHandleSize - 2, gripY + offset);
                Utils.DrawLine(spriteBatch, start, end, Color.Gray * 0.6f, Color.Gray * 0.6f, 1f);
            }
        }

        private void HandleInventoryShiftClick()
        {
            if (_connectedDiskIds.Count == 0)
                return;

            var player = Main.LocalPlayer;
            for (int i = 0; i < 50; i++)
            {
                if (player.inventory[i].IsAir)
                    continue;

                if (!StorageBlockUIState.IsMouseOverInventorySlot(i))
                    continue;

                int leftover = StorageWorldSystem.Instance.InsertItem(_connectedDiskIds, player.inventory[i]);
                if (leftover <= 0)
                    player.inventory[i].TurnToAir();
                else
                    player.inventory[i].stack = leftover;

                SoundEngine.PlaySound(SoundID.Grab);
                RefreshItems();
                return;
            }
        }
    }
}
