using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.GameContent;
using Terraria.GameContent.UI.Elements;
using Terraria.GameInput;
using Terraria.UI;
using TerraStorage.Helpers;
using TerraStorage.Systems;

namespace TerraStorage.Content.UI.Elements
{
    public class UICraftingPanel : UIElement
    {
        private const int CellSize = 44;

        private List<Guid> _diskIds = new();
        private HashSet<int> _availableStations = new();
        private List<(Recipe recipe, bool canCraft)> _allRecipes = new();
        private List<(Recipe recipe, bool canCraft)> _filteredRecipes = new();
        private Recipe _selectedRecipe;
        private bool _selectedCanCraft;
        private CraftingPlan _currentPlan;
        private UICategoryFilterBar _categoryFilter;

        private UIPanel _recipeGridPanel;
        private UIPanel _detailPanel;
        private UIScrollbar _recipeScrollbar;
        private int _craftAmount = 1;
        private bool _showUncraftable = false;
        private string _searchText = "";

        // Amount input field
        private bool _amountFieldFocused;
        private string _amountFieldText = "1";
        private readonly TextInputHelper _amountInput = new();

        // Name cache for search filtering
        private static readonly Dictionary<int, string> _recipeNameCache = new();

        // Change detection
        private long _lastStorageVersion = -1;

        public void SetDiskIds(List<Guid> diskIds)
        {
            _diskIds = diskIds ?? new List<Guid>();
            RefreshRecipes();
        }

        public void SetAvailableStations(HashSet<int> stations)
        {
            _availableStations = stations ?? new HashSet<int>();
            RefreshRecipes();
        }

        public void SetCategoryFilter(UICategoryFilterBar filterBar)
        {
            _categoryFilter = filterBar;
        }

        public void SetSearchText(string text)
        {
            _searchText = text ?? "";
            FilterRecipes();
        }

        public void RefreshFilteredRecipes()
        {
            FilterRecipes();
        }

        public override void OnInitialize()
        {
            // Recipe grid panel (left side)
            _recipeGridPanel = new UIPanel();
            _recipeGridPanel.Width.Set(0, 0.55f);
            _recipeGridPanel.Height.Set(0, 1f);
            _recipeGridPanel.Left.Set(0, 0f);
            _recipeGridPanel.Top.Set(0, 0f);
            _recipeGridPanel.BackgroundColor = new Color(23, 33, 69) * 0.8f;
            Append(_recipeGridPanel);

            // Recipe scrollbar
            _recipeScrollbar = new UIScrollbar();
            _recipeScrollbar.Height.Set(-10, 1f);
            _recipeScrollbar.Left.Set(-20, 1f);
            _recipeScrollbar.Top.Set(5, 0f);
            _recipeGridPanel.Append(_recipeScrollbar);

            // Detail panel (right side)
            _detailPanel = new UIPanel();
            _detailPanel.Width.Set(-10, 0.45f);
            _detailPanel.Height.Set(0, 1f);
            _detailPanel.Left.Set(10, 0.55f);
            _detailPanel.Top.Set(0, 0f);
            _detailPanel.BackgroundColor = new Color(33, 43, 89) * 0.8f;
            Append(_detailPanel);
        }

        private void RefreshRecipes()
        {
            if (_diskIds.Count == 0)
            {
                _allRecipes.Clear();
                _filteredRecipes.Clear();
                return;
            }

            _allRecipes = RecipeResolver.GetAllRecipesWithStations(_diskIds, _availableStations);
            FilterRecipes();
        }

        private void FilterRecipes()
        {
            _filteredRecipes = new List<(Recipe, bool)>(_allRecipes);

            if (!_showUncraftable)
                _filteredRecipes = _filteredRecipes.Where(r => r.canCraft).ToList();

            if (!string.IsNullOrEmpty(_searchText))
            {
                _filteredRecipes = _filteredRecipes.Where(r =>
                {
                    int type = r.recipe.createItem.type;
                    if (!_recipeNameCache.TryGetValue(type, out string name))
                    {
                        var item = new Item();
                        item.SetDefaults(type);
                        name = item.Name;
                        _recipeNameCache[type] = name;
                    }
                    return name.Contains(_searchText, StringComparison.OrdinalIgnoreCase);
                }).ToList();
            }

            if (_categoryFilter != null)
            {
                _filteredRecipes = _filteredRecipes
                    .Where(r => _categoryFilter.PassesFilter(r.recipe.createItem.type))
                    .ToList();
            }

            // Sort: craftable first, then by item type
            _filteredRecipes.Sort((a, b) =>
            {
                if (a.canCraft != b.canCraft)
                    return a.canCraft ? -1 : 1;
                return a.recipe.createItem.type.CompareTo(b.recipe.createItem.type);
            });

            UpdateRecipeScrollbar();
        }

        private void UpdateRecipeScrollbar()
        {
            if (_recipeScrollbar == null || _recipeGridPanel == null)
                return;

            var dims = _recipeGridPanel.GetInnerDimensions();
            int columns = GetGridColumns(dims.Width);
            int totalRows = (_filteredRecipes.Count + columns - 1) / columns;
            int visibleRows = Math.Max(1, (int)(dims.Height / CellSize));
            _recipeScrollbar.SetView(visibleRows, totalRows);
        }

        private int GetGridColumns(float width)
        {
            return Math.Max(1, (int)((width - 25) / CellSize));
        }

        private void SelectRecipe(Recipe recipe, bool canCraft)
        {
            _selectedRecipe = recipe;
            _selectedCanCraft = canCraft;
            _craftAmount = 1;
            _amountFieldText = "1";
            _amountFieldFocused = false;

            if (recipe != null)
                _currentPlan = RecipeResolver.Resolve(recipe.createItem.type,
                    _craftAmount * recipe.createItem.stack, _diskIds, _availableStations);
            else
                _currentPlan = null;
        }

        private void SetCraftAmount(int amount)
        {
            _craftAmount = Math.Max(1, Math.Min(9999, amount));
            _amountFieldText = _craftAmount.ToString();
            UpdatePlan();
        }

        private void UpdatePlan()
        {
            if (_selectedRecipe != null)
            {
                _currentPlan = RecipeResolver.Resolve(
                    _selectedRecipe.createItem.type,
                    _craftAmount * _selectedRecipe.createItem.stack,
                    _diskIds,
                    _availableStations);
            }
        }

        public override void LeftClick(UIMouseEvent evt)
        {
            base.LeftClick(evt);

            if (_recipeGridPanel != null && _recipeGridPanel.ContainsPoint(evt.MousePosition))
                HandleRecipeGridClick(evt.MousePosition);

            if (_detailPanel != null && _detailPanel.ContainsPoint(evt.MousePosition))
                HandleDetailPanelClick(evt.MousePosition);
        }

        public override void RightClick(UIMouseEvent evt)
        {
            base.RightClick(evt);

            if (_detailPanel != null && _detailPanel.ContainsPoint(evt.MousePosition) && _selectedRecipe != null)
            {
                var dims = _detailPanel.GetInnerDimensions();
                float relY = evt.MousePosition.Y - dims.Y;
                float relX = evt.MousePosition.X - dims.X;

                float btnWidth = 40;
                float startX = 5;
                float amtY = dims.Height - 70;

                if (relY >= amtY && relY < amtY + 25)
                {
                    int[] amounts = { 1, 5, 25, 100 };
                    for (int b = 0; b < 4; b++)
                    {
                        float bx = startX + b * (btnWidth + 4);
                        if (relX >= bx && relX < bx + btnWidth)
                        {
                            SetCraftAmount(_craftAmount - amounts[b]);
                            break;
                        }
                    }
                }
            }
        }

        private void HandleRecipeGridClick(Vector2 mousePos)
        {
            var dims = _recipeGridPanel.GetInnerDimensions();
            float relX = mousePos.X - dims.X;
            float relY = mousePos.Y - dims.Y;

            // Check toggle button at top
            if (relY < 22)
            {
                _showUncraftable = !_showUncraftable;
                FilterRecipes();
                return;
            }

            int columns = GetGridColumns(dims.Width);
            float gridStartY = 25f;
            int col = (int)(relX / CellSize);
            int scrollRow = (int)(_recipeScrollbar?.ViewPosition ?? 0);
            int row = (int)((relY - gridStartY) / CellSize) + scrollRow;
            int index = row * columns + col;

            if (index >= 0 && index < _filteredRecipes.Count && col >= 0 && col < columns)
                SelectRecipe(_filteredRecipes[index].recipe, _filteredRecipes[index].canCraft);
        }

        private void HandleDetailPanelClick(Vector2 mousePos)
        {
            if (_selectedRecipe == null || _currentPlan == null)
                return;

            var dims = _detailPanel.GetInnerDimensions();
            float relY = mousePos.Y - dims.Y;
            float relX = mousePos.X - dims.X;

            float btnWidth = 40;
            float startX = 5;

            // Amount buttons row (left-click increments)
            float amtY = dims.Height - 70;
            if (relY >= amtY && relY < amtY + 25)
            {
                int[] amounts = { 1, 5, 25, 100 };
                for (int b = 0; b < 4; b++)
                {
                    float bx = startX + b * (btnWidth + 4);
                    if (relX >= bx && relX < bx + btnWidth)
                    {
                        SetCraftAmount(_craftAmount + amounts[b]);
                        break;
                    }
                }
            }

            // Input field area
            float fieldStartX = startX + 4 * (btnWidth + 4) + 4;
            if (relX >= fieldStartX && relY >= amtY && relY < amtY + 25)
            {
                _amountFieldFocused = true;
                _amountFieldText = _craftAmount.ToString();
                _amountInput.Reset();
                return;
            }

            // Craft button
            if (relY >= dims.Height - 35 && _currentPlan is { IsFeasible: true })
                ExecuteCraft();

            // Unfocus amount field if clicking elsewhere
            if (_amountFieldFocused)
            {
                _amountFieldFocused = false;
                ApplyAmountFieldText();
            }
        }

        private void ApplyAmountFieldText()
        {
            if (int.TryParse(_amountFieldText, out int val) && val > 0)
                SetCraftAmount(val);
            else
                _amountFieldText = _craftAmount.ToString();
        }

        private void ExecuteCraft()
        {
            if (_currentPlan == null || !_currentPlan.IsFeasible)
                return;

            var result = RecipeResolver.ExecutePlan(_currentPlan, _diskIds);
            if (!result.IsAir)
            {
                // Put crafted items back into storage
                StorageWorldSystem.Instance.InsertItem(_diskIds, result);
                Terraria.Audio.SoundEngine.PlaySound(Terraria.ID.SoundID.Grab);
            }

            RefreshRecipes();
            if (_selectedRecipe != null)
                UpdatePlan();
        }

        public override void ScrollWheel(UIScrollWheelEvent evt)
        {
            base.ScrollWheel(evt);
            if (_recipeGridPanel != null && _recipeGridPanel.ContainsPoint(Main.MouseScreen))
                _recipeScrollbar.ViewPosition -= evt.ScrollWheelValue / 120f;
        }

        protected override void DrawChildren(SpriteBatch spriteBatch)
        {
            base.DrawChildren(spriteBatch);

            if (_recipeGridPanel != null)
                DrawRecipeGrid(spriteBatch);

            if (_detailPanel != null && _selectedRecipe != null)
                DrawDetailPanel(spriteBatch);
            else if (_detailPanel != null)
                DrawEmptyDetail(spriteBatch);
        }

        private void DrawRecipeGrid(SpriteBatch spriteBatch)
        {
            var dims = _recipeGridPanel.GetInnerDimensions();
            int columns = GetGridColumns(dims.Width);

            // Checkbox for show uncraftable
            var checkRect = new Rectangle((int)dims.X, (int)dims.Y, (int)dims.Width - 25, 20);
            bool checkHover = checkRect.Contains(Main.MouseScreen.ToPoint());
            string checkBox = _showUncraftable ? "[X]" : "[  ]";
            Color checkColor = checkHover ? Color.White : Color.LightGray;
            Utils.DrawBorderString(spriteBatch, $"{checkBox} Show Uncraftable",
                new Vector2(dims.X + 4, dims.Y + 1), checkColor, 0.65f);

            float gridStartY = dims.Y + 25;
            int visibleRows = Math.Max(1, (int)((dims.Height - 25) / CellSize));
            int scrollRow = (int)(_recipeScrollbar?.ViewPosition ?? 0);

            if (_filteredRecipes.Count == 0)
            {
                string msg = _availableStations.Count == 0
                    ? "No Crafting Core connected!"
                    : "No recipes match filters";
                Utils.DrawBorderString(spriteBatch, msg,
                    new Vector2(dims.X + 5, gridStartY + 5), Color.Gray, 0.7f);
                return;
            }

            for (int row = 0; row < visibleRows; row++)
            {
                for (int col = 0; col < columns; col++)
                {
                    int index = (scrollRow + row) * columns + col;
                    float x = dims.X + col * CellSize;
                    float y = gridStartY + row * CellSize;

                    var cellRect = new Rectangle((int)x, (int)y, CellSize - 2, CellSize - 2);

                    if (index >= 0 && index < _filteredRecipes.Count)
                    {
                        var (recipe, canCraft) = _filteredRecipes[index];
                        bool isSelected = recipe == _selectedRecipe;

                        // Cell background: bright gold for selected, red for uncraftable, blue for craftable
                        Color cellBg;
                        if (isSelected)
                            cellBg = new Color(120, 140, 220);
                        else if (!canCraft)
                            cellBg = new Color(100, 30, 30) * 0.7f;
                        else
                            cellBg = new Color(63, 82, 151) * 0.4f;

                        Utils.DrawInvBG(spriteBatch, cellRect, cellBg);
                        DrawCellItem(spriteBatch, recipe.createItem.type, recipe.createItem.stack, cellRect);

                        // Hover tooltip
                        if (cellRect.Contains(Main.MouseScreen.ToPoint()))
                        {
                            var hoverItem = new Item();
                            hoverItem.SetDefaults(recipe.createItem.type);
                            hoverItem.stack = recipe.createItem.stack;
                            Main.HoverItem = hoverItem;
                            Main.hoverItemName = hoverItem.Name;
                        }
                    }
                    else
                    {
                        Utils.DrawInvBG(spriteBatch, cellRect, new Color(63, 82, 151) * 0.2f);
                    }
                }
            }
        }

        private void DrawDetailPanel(SpriteBatch spriteBatch)
        {
            var dims = _detailPanel.GetInnerDimensions();
            float y = dims.Y + 5;

            var resultItem = new Item();
            resultItem.SetDefaults(_selectedRecipe.createItem.type);
            int totalOutput = _craftAmount * _selectedRecipe.createItem.stack;

            // Draw result item icon + name
            DrawItemIcon(spriteBatch, _selectedRecipe.createItem.type,
                new Vector2(dims.X + 20, y + 12), 0.8f);
            Utils.DrawBorderString(spriteBatch, $"{resultItem.Name} x{totalOutput}",
                new Vector2(dims.X + 38, y), Color.White, 0.85f);
            y += 28;

            // Required stations as cell icons
            bool hasStations = false;
            float stationStartX = dims.X + 5;
            float stationX = stationStartX;
            int stationCellSize = 42;

            foreach (int tileType in _selectedRecipe.requiredTile)
            {
                if (tileType < 0) continue;
                if (!hasStations)
                {
                    Utils.DrawBorderString(spriteBatch, "Stations:",
                        new Vector2(dims.X + 5, y), Color.LightGoldenrodYellow, 0.7f);
                    y += 18;
                    hasStations = true;
                }

                bool available = _availableStations.Contains(tileType);
                int stationItemType = RecipeResolver.GetTileItemType(tileType);
                Color cellBg = available
                    ? new Color(40, 120, 40) * 0.4f
                    : new Color(140, 40, 40) * 0.4f;

                var stationRect = new Rectangle((int)stationX, (int)y, stationCellSize - 2, stationCellSize - 2);
                Utils.DrawInvBG(spriteBatch, stationRect, cellBg);

                if (stationItemType > 0)
                    DrawCellItem(spriteBatch, stationItemType, 0, stationRect);

                // Tooltip on hover
                if (stationRect.Contains(Main.MouseScreen.ToPoint()))
                {
                    string stationName = RecipeResolver.GetTileName(tileType);
                    Main.hoverItemName = stationName + (available ? " (Available)" : " (Missing)");
                    if (stationItemType > 0)
                    {
                        var hoverItem = new Item();
                        hoverItem.SetDefaults(stationItemType);
                        Main.HoverItem = hoverItem;
                    }
                }

                stationX += stationCellSize;
                if (stationX + stationCellSize > dims.X + dims.Width - 10)
                {
                    stationX = stationStartX;
                    y += stationCellSize;
                }
            }
            if (hasStations) y += stationCellSize + 3;

            // Ingredients as item icons with colored count
            Utils.DrawBorderString(spriteBatch, "Ingredients:",
                new Vector2(dims.X + 5, y), Color.Yellow, 0.7f);
            y += 18;

            float ingStartX = dims.X + 5;
            float ingX = ingStartX;
            int ingCellSize = 42;

            foreach (var ingredient in _selectedRecipe.requiredItem)
            {
                if (ingredient.type <= 0) continue;

                int needed = ingredient.stack * _craftAmount;
                int inStorage = StorageWorldSystem.Instance.CountItem(_diskIds, ingredient.type);
                int inInventory = CountPlayerItem(ingredient.type);
                int totalHave = inStorage + inInventory;

                // Determine color: green = enough, yellow = have some, red = none
                Color countColor;
                if (totalHave >= needed)
                    countColor = Color.LightGreen;
                else if (totalHave > 0)
                    countColor = Color.Yellow;
                else
                    countColor = Color.IndianRed;

                var ingRect = new Rectangle((int)ingX, (int)y, ingCellSize - 2, ingCellSize - 2);
                Utils.DrawInvBG(spriteBatch, ingRect, new Color(63, 82, 151) * 0.4f);
                DrawCellItem(spriteBatch, ingredient.type, 0, ingRect);

                // Draw needed count in bottom-right with colored text
                string countText = needed.ToString();
                Utils.DrawBorderString(spriteBatch, countText,
                    new Vector2(ingRect.Right - 4, ingRect.Bottom - 4),
                    countColor, 0.6f, 1f, 1f);

                // Tooltip on hover
                if (ingRect.Contains(Main.MouseScreen.ToPoint()))
                {
                    var hoverItem = new Item();
                    hoverItem.SetDefaults(ingredient.type);
                    Main.HoverItem = hoverItem;
                    Main.hoverItemName = $"{hoverItem.Name} ({totalHave}/{needed})";
                }

                ingX += ingCellSize;
                if (ingX + ingCellSize > dims.X + dims.Width - 10)
                {
                    ingX = ingStartX;
                    y += ingCellSize;
                }
            }
            y += ingCellSize + 5;

            // Crafting steps info (condensed)
            if (_currentPlan != null && _currentPlan.Steps.Count > 1)
            {
                Utils.DrawBorderString(spriteBatch, $"Crafting chain: {_currentPlan.Steps.Count} steps",
                    new Vector2(dims.X + 5, y), Color.LightGray, 0.65f);
                y += 16;

                foreach (var step in _currentPlan.Steps)
                {
                    var stepItem = new Item();
                    stepItem.SetDefaults(step.ProducedType);
                    DrawItemIcon(spriteBatch, step.ProducedType,
                        new Vector2(dims.X + 18, y + 8), 0.4f);
                    Utils.DrawBorderString(spriteBatch, $"{stepItem.Name} x{step.ProducedCount}",
                        new Vector2(dims.X + 32, y), Color.LightGray, 0.55f);
                    y += 16;
                    if (y > dims.Y + dims.Height - 110) break;
                }
            }

            // Amount controls - single row, left-click increments, right-click decrements
            float btnWidth = 40;
            float startX = dims.X + 5;
            float amtY = dims.Y + dims.Height - 70;
            int[] amounts = { 1, 5, 25, 100 };

            for (int i = 0; i < 4; i++)
            {
                float btnX = startX + i * (btnWidth + 4);
                var btnRect = new Rectangle((int)btnX, (int)amtY, (int)btnWidth, 25);
                bool hover = btnRect.Contains(Main.MouseScreen.ToPoint());
                Color bgColor = hover ? new Color(83, 104, 181) : new Color(53, 74, 141);
                Utils.DrawInvBG(spriteBatch, btnRect, bgColor);

                string label = amounts[i].ToString();
                var labelSize = FontAssets.MouseText.Value.MeasureString(label) * 0.7f;
                Utils.DrawBorderString(spriteBatch, label,
                    new Vector2(btnX + btnWidth / 2 - labelSize.X / 2, amtY + 3), Color.White, 0.7f);

                if (hover)
                {
                    Main.LocalPlayer.mouseInterface = true;
                    Main.hoverItemName = $"Left-click: +{amounts[i]}  |  Right-click: -{amounts[i]}";
                }
            }

            // Amount input field
            float fieldX = startX + 4 * (btnWidth + 4) + 4;
            float fieldWidth = dims.X + dims.Width - fieldX - 10;
            if (fieldWidth > 20)
            {
                var fieldRect = new Rectangle((int)fieldX, (int)amtY, (int)fieldWidth, 25);
                Color fieldBg = _amountFieldFocused ? new Color(45, 55, 100) : new Color(35, 43, 79) * 0.9f;
                Utils.DrawInvBG(spriteBatch, fieldRect, fieldBg);

                string fieldDisplay = _amountFieldText;
                if (_amountFieldFocused && (int)(Main.GameUpdateCount / 20) % 2 == 0)
                    fieldDisplay += "|";

                Utils.DrawBorderString(spriteBatch, fieldDisplay,
                    new Vector2(fieldX + 6, amtY + 2), Color.White, 0.8f);
            }

            // Craft button
            float craftBtnY = dims.Y + dims.Height - 35;
            var craftRect = new Rectangle((int)dims.X + 5, (int)craftBtnY, (int)dims.Width - 10, 30);
            bool feasible = _currentPlan is { IsFeasible: true };
            Color craftColor = feasible ? new Color(50, 150, 50) : new Color(150, 50, 50);
            Utils.DrawInvBG(spriteBatch, craftRect, craftColor);

            string craftText;
            if (_currentPlan != null && _currentPlan.MissingStations.Count > 0)
                craftText = "Missing Stations";
            else if (feasible)
                craftText = $"CRAFT x{_craftAmount} ({totalOutput} items)";
            else
                craftText = "Missing Materials";

            var textSize = FontAssets.MouseText.Value.MeasureString(craftText) * 0.8f;
            Utils.DrawBorderString(spriteBatch, craftText,
                new Vector2(dims.X + dims.Width / 2 - textSize.X / 2, craftBtnY + 5), Color.White, 0.8f);
        }

        private void DrawEmptyDetail(SpriteBatch spriteBatch)
        {
            var dims = _detailPanel.GetInnerDimensions();
            float y = dims.Y + 10;

            Utils.DrawBorderString(spriteBatch, "Select a recipe",
                new Vector2(dims.X + 10, y), Color.Gray, 0.9f);
            y += 30;

            if (_availableStations.Count > 0)
            {
                Utils.DrawBorderString(spriteBatch, "Available stations:",
                    new Vector2(dims.X + 10, y), Color.LightGoldenrodYellow, 0.75f);
                y += 20;

                float sX = dims.X + 5;
                int sCellSize = 42;

                foreach (int tileType in _availableStations)
                {
                    int stationItemType = RecipeResolver.GetTileItemType(tileType);
                    var sRect = new Rectangle((int)sX, (int)y, sCellSize - 2, sCellSize - 2);
                    Utils.DrawInvBG(spriteBatch, sRect, new Color(40, 120, 40) * 0.4f);

                    if (stationItemType > 0)
                        DrawCellItem(spriteBatch, stationItemType, 0, sRect);

                    if (sRect.Contains(Main.MouseScreen.ToPoint()))
                    {
                        Main.hoverItemName = RecipeResolver.GetTileName(tileType);
                        if (stationItemType > 0)
                        {
                            var hoverItem = new Item();
                            hoverItem.SetDefaults(stationItemType);
                            Main.HoverItem = hoverItem;
                        }
                    }

                    sX += sCellSize;
                    if (sX + sCellSize > dims.X + dims.Width - 10)
                    {
                        sX = dims.X + 5;
                        y += sCellSize;
                    }
                }
                y += sCellSize;
            }
            else
            {
                Utils.DrawBorderString(spriteBatch, "No Crafting Core connected",
                    new Vector2(dims.X + 10, y), Color.IndianRed, 0.75f);
                y += 20;
                Utils.DrawBorderString(spriteBatch, "Place a Crafting Core nearby",
                    new Vector2(dims.X + 10, y), Color.Gray, 0.7f);
                y += 18;
                Utils.DrawBorderString(spriteBatch, "and insert crafting stations",
                    new Vector2(dims.X + 10, y), Color.Gray, 0.7f);
            }
        }

        private static int CountPlayerItem(int itemType)
        {
            int count = 0;
            var player = Main.LocalPlayer;
            for (int i = 0; i < 50; i++)
            {
                if (player.inventory[i] != null && !player.inventory[i].IsAir && player.inventory[i].type == itemType)
                    count += player.inventory[i].stack;
            }
            return count;
        }

        private void DrawCellItem(SpriteBatch spriteBatch, int itemType, int stack, Rectangle cellRect)
        {
            Main.instance.LoadItem(itemType);
            var texture = TextureAssets.Item[itemType].Value;
            var sourceRect = Main.itemAnimations[itemType] != null
                ? Main.itemAnimations[itemType].GetFrame(texture)
                : texture.Frame();

            float scale = 1f;
            float maxDim = Math.Max(sourceRect.Width, sourceRect.Height);
            if (maxDim > 27)
                scale = 27f / maxDim;

            var center = new Vector2(cellRect.X + cellRect.Width / 2, cellRect.Y + cellRect.Height / 2);
            var origin = new Vector2(sourceRect.Width / 2, sourceRect.Height / 2);

            spriteBatch.Draw(texture, center, sourceRect, Color.White, 0f, origin, scale, SpriteEffects.None, 0f);

            if (stack > 1)
            {
                string countText = stack >= 1000 ? $"{stack / 1000f:0.#}k" : stack.ToString();
                Utils.DrawBorderString(spriteBatch, countText,
                    new Vector2(cellRect.Right - 4, cellRect.Bottom - 4),
                    Color.White, 0.6f, 1f, 1f);
            }
        }

        private void DrawItemIcon(SpriteBatch spriteBatch, int itemType, Vector2 center, float baseScale, Color? tint = null)
        {
            Main.instance.LoadItem(itemType);
            var texture = TextureAssets.Item[itemType].Value;
            var sourceRect = Main.itemAnimations[itemType] != null
                ? Main.itemAnimations[itemType].GetFrame(texture)
                : texture.Frame();

            float scale = baseScale;
            float maxDim = Math.Max(sourceRect.Width, sourceRect.Height);
            if (maxDim > 29) scale *= 29f / maxDim;

            spriteBatch.Draw(texture, center, sourceRect, tint ?? Color.White, 0f,
                new Vector2(sourceRect.Width / 2, sourceRect.Height / 2), scale, SpriteEffects.None, 0f);
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            // Handle amount field text input
            if (_amountFieldFocused)
            {
                Main.chatRelease = false;
                PlayerInput.WritingText = true;
                Main.CurrentInputTextTakerOverride = this;

                string prev = _amountFieldText;
                string newText = _amountInput.ProcessInput(prev, maxLength: 4, digitsOnly: true);

                if (newText != prev)
                {
                    _amountFieldText = newText;
                    if (int.TryParse(newText, out int val) && val > 0)
                    {
                        _craftAmount = Math.Min(9999, val);
                        UpdatePlan();
                    }
                }

                if (Keyboard.GetState().IsKeyDown(Keys.Escape) || Keyboard.GetState().IsKeyDown(Keys.Enter))
                {
                    _amountFieldFocused = false;
                    ApplyAmountFieldText();
                }
            }

            // Refresh recipes when storage contents change
            long currentVersion = StorageWorldSystem.Instance.StorageVersion;
            if (currentVersion != _lastStorageVersion)
            {
                _lastStorageVersion = currentVersion;
                RefreshRecipes();
            }
        }
    }
}
