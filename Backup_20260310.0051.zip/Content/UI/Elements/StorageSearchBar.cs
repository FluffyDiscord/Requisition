using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.GameContent;
using Terraria.GameContent.UI.Elements;
using Terraria.GameInput;
using Terraria.UI;

namespace TerraStorage.Content.UI.Elements
{
    public class StorageSearchBar : UIPanel
    {
        public string SearchText { get; private set; } = "";
        public event Action<string> OnTextChanged;
        private bool _focused;
        private int _cursorBlink;
        private readonly TextInputHelper _input = new();

        public StorageSearchBar()
        {
            BackgroundColor = new Color(35, 43, 79) * 0.9f;
            BorderColor = new Color(89, 116, 213) * 0.7f;
        }

        public override void LeftClick(UIMouseEvent evt)
        {
            base.LeftClick(evt);
            _focused = true;
            _input.Reset();
        }

        public override void RightClick(UIMouseEvent evt)
        {
            base.RightClick(evt);
            if (!string.IsNullOrEmpty(SearchText))
            {
                SearchText = "";
                OnTextChanged?.Invoke(SearchText);
            }
            _focused = false;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            if (_focused)
            {
                // Check for click outside
                if (Main.mouseLeft && !ContainsPoint(Main.MouseScreen))
                {
                    _focused = false;
                    return;
                }

                // Prevent player from chatting/using items while typing
                Main.chatRelease = false;
                PlayerInput.WritingText = true;
                Main.CurrentInputTextTakerOverride = this;

                string prev = SearchText ?? "";
                string newText = _input.ProcessInput(prev);
                if (newText != prev)
                {
                    SearchText = newText;
                    OnTextChanged?.Invoke(SearchText);
                }

                // Escape to unfocus and clear
                if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                {
                    _focused = false;
                    SearchText = "";
                    OnTextChanged?.Invoke(SearchText);
                }

                _cursorBlink++;
            }
        }

        protected override void DrawSelf(SpriteBatch spriteBatch)
        {
            base.DrawSelf(spriteBatch);

            var dims = GetInnerDimensions();
            string displayText = SearchText;

            if (string.IsNullOrEmpty(displayText) && !_focused)
                displayText = "Search items...";

            Color textColor = string.IsNullOrEmpty(SearchText) && !_focused
                ? Color.Gray
                : Color.White;

            float textHeight = FontAssets.MouseText.Value.MeasureString("A").Y * 0.9f;
            float textY = (dims.Y + (dims.Height - textHeight) / 2f) + 2;

            Utils.DrawBorderString(spriteBatch, displayText, new Vector2(dims.X + 4, textY), textColor, 0.9f);

            // Draw cursor
            if (_focused && _cursorBlink % 40 < 20)
            {
                float textWidth = FontAssets.MouseText.Value.MeasureString(displayText).X * 0.9f;
                Utils.DrawBorderString(spriteBatch, "|", new Vector2(dims.X + 4 + textWidth, textY), Color.White, 0.9f);
            }
        }
    }
}
