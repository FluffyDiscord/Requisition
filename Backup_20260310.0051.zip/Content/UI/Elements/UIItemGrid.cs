using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;
using Terraria.GameContent.UI.Elements;
using Terraria.UI;
using TerraStorage.Systems;

namespace TerraStorage.Content.UI.Elements
{
    public class UIItemGrid : UIElement
    {
        private List<ConsolidatedItem> _items = new();
        private UIScrollbar _scrollbar;
        private int _columns = 8;
        private int _cellSize = 48;

        public event Action<ConsolidatedItem> OnItemClicked;
        public event Action<ConsolidatedItem> OnItemRightClicked;

        public void SetItems(List<ConsolidatedItem> items)
        {
            _items = items ?? new List<ConsolidatedItem>();
            UpdateScrollbar();
        }

        public void SetColumns(int columns)
        {
            _columns = Math.Max(1, columns);
            UpdateScrollbar();
        }

        public void SetScrollbar(UIScrollbar scrollbar)
        {
            _scrollbar = scrollbar;
        }

        private void UpdateScrollbar()
        {
            if (_scrollbar == null)
                return;

            int totalRows = (_items.Count + _columns - 1) / _columns;
            var dims = GetDimensions();
            int visibleRows = (int)(dims.Height / _cellSize);
            _scrollbar.SetView(visibleRows, totalRows);
        }

        public override void ScrollWheel(UIScrollWheelEvent evt)
        {
            base.ScrollWheel(evt);
            if (_scrollbar != null)
            {
                _scrollbar.ViewPosition -= evt.ScrollWheelValue / 120f;
            }
        }

        public override void LeftClick(UIMouseEvent evt)
        {
            base.LeftClick(evt);
            var item = GetItemAtMouse(evt.MousePosition);
            if (item != null)
                OnItemClicked?.Invoke(item);
        }

        public override void RightClick(UIMouseEvent evt)
        {
            base.RightClick(evt);
            var item = GetItemAtMouse(evt.MousePosition);
            if (item != null)
                OnItemRightClicked?.Invoke(item);
        }

        private ConsolidatedItem GetItemAtMouse(Vector2 mousePos)
        {
            var dims = GetDimensions();
            float relX = mousePos.X - dims.X;
            float relY = mousePos.Y - dims.Y;

            int col = (int)(relX / _cellSize);
            int scrollRow = _scrollbar != null ? (int)_scrollbar.ViewPosition : 0;
            int row = (int)(relY / _cellSize) + scrollRow;
            int index = row * _columns + col;

            if (index >= 0 && index < _items.Count && col >= 0 && col < _columns)
                return _items[index];

            return null;
        }

        protected override void DrawSelf(SpriteBatch spriteBatch)
        {
            var dims = GetDimensions();
            int visibleRows = (int)(dims.Height / _cellSize);
            int scrollRow = _scrollbar != null ? (int)_scrollbar.ViewPosition : 0;

            // Draw background
            Utils.DrawInvBG(spriteBatch, dims.ToRectangle(), new Color(23, 33, 69) * 0.8f);

            for (int row = 0; row < visibleRows; row++)
            {
                for (int col = 0; col < _columns; col++)
                {
                    int index = (scrollRow + row) * _columns + col;
                    float x = dims.X + col * _cellSize;
                    float y = dims.Y + row * _cellSize;

                    var cellRect = new Rectangle((int)x, (int)y, _cellSize - 2, _cellSize - 2);

                    // Draw cell background
                    Utils.DrawInvBG(spriteBatch, cellRect, new Color(63, 82, 151) * 0.4f);

                    if (index >= 0 && index < _items.Count)
                    {
                        var consolidatedItem = _items[index];
                        DrawItem(spriteBatch, consolidatedItem, cellRect);

                        // Hover tooltip
                        if (cellRect.Contains(Main.MouseScreen.ToPoint()))
                        {
                            var hoverItem = new Item();
                            hoverItem.SetDefaults(consolidatedItem.ItemType);
                            if (consolidatedItem.PrefixId > 0)
                                hoverItem.Prefix(consolidatedItem.PrefixId);
                            hoverItem.stack = consolidatedItem.TotalCount;
                            Main.HoverItem = hoverItem;
                            Main.hoverItemName = hoverItem.Name;
                        }
                    }
                }
            }
        }

        private void DrawItem(SpriteBatch spriteBatch, ConsolidatedItem ci, Rectangle cellRect)
        {
            Main.instance.LoadItem(ci.ItemType);
            var texture = TextureAssets.Item[ci.ItemType].Value;
            var sourceRect = Main.itemAnimations[ci.ItemType] != null
                ? Main.itemAnimations[ci.ItemType].GetFrame(texture)
                : texture.Frame();

            float scale = 1f;
            float maxDim = Math.Max(sourceRect.Width, sourceRect.Height);
            if (maxDim > 29)
                scale = 29f / maxDim;

            var center = new Vector2(cellRect.X + cellRect.Width / 2, cellRect.Y + cellRect.Height / 2);
            var origin = new Vector2(sourceRect.Width / 2, sourceRect.Height / 2);

            spriteBatch.Draw(texture, center, sourceRect, Color.White, 0f, origin, scale, SpriteEffects.None, 0f);

            // Draw count
            if (ci.TotalCount > 1)
            {
                string countText = ci.TotalCount >= 1000
                    ? $"{ci.TotalCount / 1000f:0.#}k"
                    : ci.TotalCount.ToString();

                Utils.DrawBorderString(spriteBatch, countText,
                    new Vector2(cellRect.Right - 4, cellRect.Bottom - 4),
                    Color.White, 0.7f, 1f, 1f);
            }
        }
    }
}
