using System;
using System.Collections.Generic;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using TerraStorage.Common;
using TerraStorage.Systems;

namespace TerraStorage.Content.Items
{
    public abstract class StorageDiskBase : ModItem
    {
        public abstract DiskTier Tier { get; }

        public Guid DiskId { get; set; } = Guid.Empty;

        public override void SetDefaults()
        {
            Item.width = 24;
            Item.height = 24;
            Item.maxStack = 1;
            Item.value = Item.buyPrice(gold: (int)Tier + 1);
            Item.rare = (int)Tier + 1;
        }

        public override void OnCreated(ItemCreationContext context)
        {
            if (DiskId == Guid.Empty)
            {
                DiskId = Guid.NewGuid();
                // Only register with world system if it's available (not during mod loading)
                StorageWorldSystem.Instance?.RegisterDisk(DiskId, Tier);
            }
        }

        public override void SaveData(TagCompound tag)
        {
            if (DiskId != Guid.Empty)
                tag["diskId"] = DiskId.ToByteArray();
        }

        public override void LoadData(TagCompound tag)
        {
            if (tag.ContainsKey("diskId"))
                DiskId = new Guid(tag.GetByteArray("diskId"));
        }

        public override ModItem Clone(Item newEntity)
        {
            var clone = (StorageDiskBase)base.Clone(newEntity);
            clone.DiskId = DiskId;
            return clone;
        }

        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            var tierColor = Tier.GetColor();
            tooltips.Add(new TooltipLine(Mod, "DiskTier", $"[c/{tierColor.R:X2}{tierColor.G:X2}{tierColor.B:X2}:{Tier.GetName()} Storage Disk]"));

            if (DiskId != Guid.Empty)
            {
                var diskData = StorageWorldSystem.Instance.GetDiskData(DiskId);
                int used = diskData?.UsedStacks ?? 0;
                int max = Tier.GetCapacity();
                tooltips.Add(new TooltipLine(Mod, "DiskUsage", $"Stored: {used} / {max} stacks"));

                string shortId = DiskId.ToString()[..8];
                tooltips.Add(new TooltipLine(Mod, "DiskId", $"ID: {shortId}..."));
            }
            else
            {
                tooltips.Add(new TooltipLine(Mod, "DiskUninitialized", "Uninitialized - place in a Drive Bay"));
            }
        }

        /// <summary>
        /// Assign a specific Guid to this disk (for restoration).
        /// </summary>
        public void AssignDiskId(Guid id)
        {
            DiskId = id;
        }
    }
}
