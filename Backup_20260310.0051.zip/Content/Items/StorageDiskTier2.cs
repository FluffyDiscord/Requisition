using TerraStorage.Common;

namespace TerraStorage.Content.Items
{
    public class StorageDiskTier2 : StorageDiskBase
    {
        public override DiskTier Tier => DiskTier.Tier2;
    }
}
