using TerraStorage.Common;

namespace TerraStorage.Content.Items
{
    public class StorageDiskTier5 : StorageDiskBase
    {
        public override DiskTier Tier => DiskTier.Tier5;
    }
}
