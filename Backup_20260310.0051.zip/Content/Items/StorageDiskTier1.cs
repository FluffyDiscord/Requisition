using TerraStorage.Common;

namespace TerraStorage.Content.Items
{
    public class StorageDiskTier1 : StorageDiskBase
    {
        public override DiskTier Tier => DiskTier.Tier1;
    }
}
