using TerraStorage.Common;

namespace TerraStorage.Content.Items
{
    public class StorageDiskTier4 : StorageDiskBase
    {
        public override DiskTier Tier => DiskTier.Tier4;
    }
}
