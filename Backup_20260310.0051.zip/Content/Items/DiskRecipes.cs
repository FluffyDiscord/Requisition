using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TerraStorage.Content.Items
{
    public class DiskRecipeSystem : ModSystem
    {
        public override void AddRecipes()
        {
            // Tier 1: Basic Storage Disk (64 stacks)
            Recipe.Create(ModContent.ItemType<StorageDiskTier1>())
                .AddIngredient(ItemID.IronBar, 5)
                .AddIngredient(ItemID.Glass, 3)
                .AddTile(TileID.WorkBenches)
                .Register();

            Recipe.Create(ModContent.ItemType<StorageDiskTier1>())
                .AddIngredient(ItemID.LeadBar, 5)
                .AddIngredient(ItemID.Glass, 3)
                .AddTile(TileID.WorkBenches)
                .Register();

            // Tier 2: Advanced Storage Disk (128 stacks)
            Recipe.Create(ModContent.ItemType<StorageDiskTier2>())
                .AddIngredient(ModContent.ItemType<StorageDiskTier1>())
                .AddIngredient(ItemID.SilverBar, 8)
                .AddIngredient(ItemID.Sapphire, 2)
                .AddTile(TileID.WorkBenches)
                .Register();

            Recipe.Create(ModContent.ItemType<StorageDiskTier2>())
                .AddIngredient(ModContent.ItemType<StorageDiskTier1>())
                .AddIngredient(ItemID.TungstenBar, 8)
                .AddIngredient(ItemID.Sapphire, 2)
                .AddTile(TileID.WorkBenches)
                .Register();

            // Tier 3: Superior Storage Disk (256 stacks)
            Recipe.Create(ModContent.ItemType<StorageDiskTier3>())
                .AddIngredient(ModContent.ItemType<StorageDiskTier2>())
                .AddIngredient(ItemID.GoldBar, 10)
                .AddIngredient(ItemID.Ruby, 3)
                .AddTile(TileID.Anvils)
                .Register();

            Recipe.Create(ModContent.ItemType<StorageDiskTier3>())
                .AddIngredient(ModContent.ItemType<StorageDiskTier2>())
                .AddIngredient(ItemID.PlatinumBar, 10)
                .AddIngredient(ItemID.Ruby, 3)
                .AddTile(TileID.Anvils)
                .Register();

            // Tier 4: Elite Storage Disk (512 stacks)
            Recipe.Create(ModContent.ItemType<StorageDiskTier4>())
                .AddIngredient(ModContent.ItemType<StorageDiskTier3>())
                .AddIngredient(ItemID.HellstoneBar, 12)
                .AddIngredient(ItemID.Diamond, 5)
                .AddTile(TileID.Anvils)
                .Register();

            // Tier 5: Ultimate Storage Disk (1024 stacks)
            Recipe.Create(ModContent.ItemType<StorageDiskTier5>())
                .AddIngredient(ModContent.ItemType<StorageDiskTier4>())
                .AddIngredient(ItemID.HallowedBar, 15)
                .AddIngredient(ItemID.SoulofLight, 10)
                .AddIngredient(ItemID.SoulofNight, 10)
                .AddTile(TileID.MythrilAnvil)
                .Register();

            // Tier 6: Infinite Storage Disk (2048 stacks)
            Recipe.Create(ModContent.ItemType<StorageDiskTier6>())
                .AddIngredient(ModContent.ItemType<StorageDiskTier5>())
                .AddIngredient(ItemID.LunarBar, 20)
                .AddIngredient(ItemID.FragmentSolar, 5)
                .AddIngredient(ItemID.FragmentVortex, 5)
                .AddIngredient(ItemID.FragmentNebula, 5)
                .AddIngredient(ItemID.FragmentStardust, 5)
                .AddTile(TileID.LunarCraftingStation)
                .Register();
        }
    }
}
