using TerraStorage.Common;

namespace TerraStorage.Content.Items
{
    public class StorageDiskTier6 : StorageDiskBase
    {
        public override DiskTier Tier => DiskTier.Tier6;
    }
}
