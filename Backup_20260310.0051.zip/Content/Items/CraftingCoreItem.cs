using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TerraStorage.Content.Tiles;

namespace TerraStorage.Content.Items
{
    public class CraftingCoreItem : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 32;
            Item.height = 32;
            Item.maxStack = 99;
            Item.useTurn = true;
            Item.autoReuse = true;
            Item.useAnimation = 15;
            Item.useTime = 10;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.consumable = true;
            Item.value = Item.buyPrice(gold: 8);
            Item.rare = ItemRarityID.Orange;
            Item.createTile = ModContent.TileType<CraftingCore>();
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.IronBar, 12)
                .AddIngredient(ItemID.Glass, 8)
                .AddIngredient(ItemID.Wire, 10)
                .AddIngredient(ItemID.Ruby, 2)
                .AddTile(TileID.WorkBenches)
                .Register();

            CreateRecipe()
                .AddIngredient(ItemID.LeadBar, 12)
                .AddIngredient(ItemID.Glass, 8)
                .AddIngredient(ItemID.Wire, 10)
                .AddIngredient(ItemID.Ruby, 2)
                .AddTile(TileID.WorkBenches)
                .Register();
        }
    }
}
