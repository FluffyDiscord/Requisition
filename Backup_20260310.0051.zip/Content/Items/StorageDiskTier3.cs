using TerraStorage.Common;

namespace TerraStorage.Content.Items
{
    public class StorageDiskTier3 : StorageDiskBase
    {
        public override DiskTier Tier => DiskTier.Tier3;
    }
}
