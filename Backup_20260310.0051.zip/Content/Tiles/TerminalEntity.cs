using System;
using System.Collections.Generic;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.ObjectData;
using TerraStorage.Content.UI;
using TerraStorage.Helpers;

namespace TerraStorage.Content.Tiles
{
    public class TerminalEntity : ModTileEntity
    {
        public override bool IsTileValidForEntity(int x, int y)
        {
            var tile = Main.tile[x, y];
            return tile.HasTile && tile.TileType == ModContent.TileType<Terminal>();
        }

        public override int Hook_AfterPlacement(int i, int j, int type, int style, int direction, int alternate)
        {
            if (Main.netMode == Terraria.ID.NetmodeID.MultiplayerClient)
            {
                int width = 3;
                int height = 3;
                NetMessage.SendTileSquare(Main.myPlayer, i, j, width, height);
                NetMessage.SendData(Terraria.ID.MessageID.TileEntityPlacement, number: i, number2: j, number3: Type);
                return -1;
            }

            return Place(i, j);
        }

        /// <summary>
        /// Get all disk IDs from all storage blocks connected to this terminal.
        /// </summary>
        public List<Guid> GetConnectedDiskIds()
        {
            return StorageNetwork.GetAllConnectedDiskIds(Position);
        }

        /// <summary>
        /// Get all crafting station tile types available from connected Crafting Cores.
        /// </summary>
        public HashSet<int> GetAvailableStations()
        {
            return StorageNetwork.GetAllAvailableStations(Position);
        }

        /// <summary>
        /// Open the terminal UI for the player.
        /// </summary>
        public void OpenTerminalUI(Player player)
        {
            var uiSystem = ModContent.GetInstance<TerminalUISystem>();
            uiSystem?.OpenTerminal(this);
        }

        /// <summary>
        /// Find the TerminalEntity at a given tile position (accounts for multi-tile).
        /// </summary>
        public static TerminalEntity FindEntity(int i, int j)
        {
            var tile = Main.tile[i, j];
            if (!tile.HasTile)
                return null;

            var tileData = TileObjectData.GetTileData(tile);
            if (tileData == null)
                return null;

            int frameX = tile.TileFrameX / 18 % tileData.Width;
            int frameY = tile.TileFrameY / 18 % tileData.Height;
            int topLeftX = i - frameX;
            int topLeftY = j - frameY;

            var key = new Point16(topLeftX + tileData.Origin.X, topLeftY + tileData.Origin.Y);
            if (TileEntity.ByPosition.TryGetValue(key, out var entity) && entity is TerminalEntity te)
                return te;

            return null;
        }
    }
}
