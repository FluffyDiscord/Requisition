using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.Enums;
using Terraria.GameContent.ObjectInteractions;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace TerraStorage.Content.Tiles
{
    public class CraftingCore : ModTile
    {
        public override void SetStaticDefaults()
        {
            Main.tileFrameImportant[Type] = true;
            Main.tileNoAttach[Type] = true;
            Main.tileLavaDeath[Type] = false;

            TileObjectData.newTile.CopyFrom(TileObjectData.Style2x2);
            TileObjectData.newTile.Origin = new Point16(0, 1);
            TileObjectData.newTile.CoordinateHeights = new[] { 16, 16 };
            TileObjectData.newTile.HookPostPlaceMyPlayer = new PlacementHook(
                ModContent.GetInstance<CraftingCoreEntity>().Hook_AfterPlacement, -1, 0, false);
            TileObjectData.newTile.UsesCustomCanPlace = true;
            TileObjectData.newTile.AnchorBottom = new AnchorData(AnchorType.SolidTile | AnchorType.SolidWithTop, 2, 0);
            TileObjectData.addTile(Type);

            AddMapEntry(new Color(180, 120, 50), CreateMapEntryName());
        }

        public override bool HasSmartInteract(int i, int j, SmartInteractScanSettings settings) => true;

        public override bool RightClick(int i, int j)
        {
            var entity = CraftingCoreEntity.FindEntity(i, j);
            if (entity != null)
            {
                entity.OpenStationUI(Main.LocalPlayer);
                return true;
            }
            return false;
        }

        public override void MouseOver(int i, int j)
        {
            var player = Main.LocalPlayer;
            player.noThrow = 2;
            player.cursorItemIconEnabled = true;
            player.cursorItemIconID = ModContent.ItemType<Items.CraftingCoreItem>();
        }

        public override void KillMultiTile(int i, int j, int frameX, int frameY)
        {
            var entity = CraftingCoreEntity.FindEntity(i, j);
            if (entity != null)
            {
                entity.DropStations(i, j);
            }

            var tileData = TileObjectData.GetTileData(Type, 0);
            int topLeftX = i - frameX / 18;
            int topLeftY = j - frameY / 18;
            ModContent.GetInstance<CraftingCoreEntity>().Kill(
                topLeftX + tileData.Origin.X, topLeftY + tileData.Origin.Y);
        }
    }
}
