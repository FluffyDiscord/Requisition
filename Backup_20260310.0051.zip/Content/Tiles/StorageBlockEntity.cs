using System;
using System.Collections.Generic;
using System.IO;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Terraria.ObjectData;
using TerraStorage.Content.Items;
using TerraStorage.Content.UI;
using TerraStorage.Helpers;
using TerraStorage.Systems;

namespace TerraStorage.Content.Tiles
{
    public class StorageBlockEntity : ModTileEntity
    {
        public const int DiskSlotCount = 40;

        public Item[] DiskSlots { get; private set; } = new Item[DiskSlotCount];

        public override void OnNetPlace()
        {
            InitializeSlots();
        }

        public override bool IsTileValidForEntity(int x, int y)
        {
            var tile = Main.tile[x, y];
            return tile.HasTile && tile.TileType == ModContent.TileType<StorageBlock>();
        }

        public override int Hook_AfterPlacement(int i, int j, int type, int style, int direction, int alternate)
        {
            if (Main.netMode == Terraria.ID.NetmodeID.MultiplayerClient)
            {
                int width = 2;
                int height = 2;
                NetMessage.SendTileSquare(Main.myPlayer, i, j, width, height);
                NetMessage.SendData(Terraria.ID.MessageID.TileEntityPlacement, number: i, number2: j, number3: Type);
                return -1;
            }

            int placedEntity = Place(i, j);
            if (TileEntity.ByID.TryGetValue(placedEntity, out var entity) && entity is StorageBlockEntity sbe)
                sbe.InitializeSlots();

            return placedEntity;
        }

        public void EnsureSlotsInitialized() => InitializeSlots();

        private void InitializeSlots()
        {
            for (int i = 0; i < DiskSlotCount; i++)
            {
                if (DiskSlots[i] == null)
                {
                    DiskSlots[i] = new Item();
                    DiskSlots[i].TurnToAir();
                }
            }
        }

        /// <summary>
        /// Get all disk IDs from inserted disks.
        /// </summary>
        public List<Guid> GetInsertedDiskIds()
        {
            var ids = new List<Guid>();
            for (int i = 0; i < DiskSlotCount; i++)
            {
                if (DiskSlots[i] != null && !DiskSlots[i].IsAir &&
                    DiskSlots[i].ModItem is StorageDiskBase disk)
                {
                    // Auto-initialize disks that haven't been registered yet
                    if (disk.DiskId == Guid.Empty)
                    {
                        disk.DiskId = Guid.NewGuid();
                        StorageWorldSystem.Instance?.RegisterDisk(disk.DiskId, disk.Tier);
                    }
                    ids.Add(disk.DiskId);
                }
            }
            return ids;
        }

        /// <summary>
        /// Try to insert a disk into the first available slot.
        /// Returns true if successful.
        /// </summary>
        public bool InsertDisk(Item diskItem, int slot = -1)
        {
            if (diskItem == null || diskItem.IsAir || diskItem.ModItem is not StorageDiskBase)
                return false;

            InitializeSlots();

            if (slot >= 0 && slot < DiskSlotCount)
            {
                if (DiskSlots[slot].IsAir)
                {
                    DiskSlots[slot] = diskItem.Clone();
                    return true;
                }
                return false;
            }

            for (int i = 0; i < DiskSlotCount; i++)
            {
                if (DiskSlots[i].IsAir)
                {
                    DiskSlots[i] = diskItem.Clone();
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Remove a disk from a specific slot. Returns the removed disk item.
        /// </summary>
        public Item RemoveDisk(int slot)
        {
            InitializeSlots();

            if (slot < 0 || slot >= DiskSlotCount || DiskSlots[slot].IsAir)
                return new Item();

            var removed = DiskSlots[slot].Clone();
            DiskSlots[slot].TurnToAir();
            return removed;
        }

        /// <summary>
        /// Drop all disks when the block is destroyed.
        /// </summary>
        public void DropDisks(int x, int y)
        {
            InitializeSlots();
            for (int i = 0; i < DiskSlotCount; i++)
            {
                if (!DiskSlots[i].IsAir)
                {
                    int idx = Item.NewItem(new EntitySource_TileBreak(x, y), x * 16, y * 16, 32, 32, DiskSlots[i].type, DiskSlots[i].stack, false, DiskSlots[i].prefix);
                    if (Main.netMode != Terraria.ID.NetmodeID.MultiplayerClient && DiskSlots[i].ModItem != null)
                        Main.item[idx] = DiskSlots[i].Clone();
                    DiskSlots[i].TurnToAir();
                }
            }
        }

        /// <summary>
        /// Open the disk insertion UI for this storage block.
        /// </summary>
        public void OpenDiskUI(Player player)
        {
            var uiSystem = ModContent.GetInstance<StorageBlockUISystem>();
            uiSystem?.OpenStorageBlock(this);
        }

        public override void SaveData(TagCompound tag)
        {
            InitializeSlots();
            var diskTags = new List<TagCompound>();
            for (int i = 0; i < DiskSlotCount; i++)
            {
                diskTags.Add(ItemIO.Save(DiskSlots[i]));
            }
            tag["disks"] = diskTags;
        }

        public override void LoadData(TagCompound tag)
        {
            InitializeSlots();
            if (tag.ContainsKey("disks"))
            {
                var diskTags = tag.GetList<TagCompound>("disks");
                for (int i = 0; i < DiskSlotCount && i < diskTags.Count; i++)
                {
                    DiskSlots[i] = ItemIO.Load(diskTags[i]);
                }
            }
        }

        public override void NetSend(BinaryWriter writer)
        {
            InitializeSlots();
            for (int i = 0; i < DiskSlotCount; i++)
            {
                ItemIO.Send(DiskSlots[i], writer, true);
            }
        }

        public override void NetReceive(BinaryReader reader)
        {
            InitializeSlots();
            for (int i = 0; i < DiskSlotCount; i++)
            {
                DiskSlots[i] = ItemIO.Receive(reader, true);
            }
        }

        /// <summary>
        /// Find the StorageBlockEntity at a given tile position (accounts for multi-tile).
        /// </summary>
        public static StorageBlockEntity FindEntity(int i, int j)
        {
            var tile = Main.tile[i, j];
            if (!tile.HasTile)
                return null;

            var tileData = TileObjectData.GetTileData(tile);
            if (tileData == null)
                return null;

            int frameX = tile.TileFrameX / 18 % tileData.Width;
            int frameY = tile.TileFrameY / 18 % tileData.Height;
            int topLeftX = i - frameX;
            int topLeftY = j - frameY;

            // Entity is placed at the Origin position, not top-left
            var key = new Point16(topLeftX + tileData.Origin.X, topLeftY + tileData.Origin.Y);
            if (TileEntity.ByPosition.TryGetValue(key, out var entity) && entity is StorageBlockEntity sbe)
                return sbe;

            return null;
        }
    }
}
