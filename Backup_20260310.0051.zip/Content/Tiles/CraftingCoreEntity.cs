using System.Collections.Generic;
using System.IO;
using System.Linq;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Terraria.ObjectData;
using TerraStorage.Content.UI;
using TerraStorage.Helpers;

namespace TerraStorage.Content.Tiles
{
    public class CraftingCoreEntity : ModTileEntity
    {
        public const int StationSlotCount = 40;

        public Item[] StationSlots { get; private set; } = new Item[StationSlotCount];

        public override void OnNetPlace()
        {
            InitializeSlots();
        }

        public override bool IsTileValidForEntity(int x, int y)
        {
            var tile = Main.tile[x, y];
            return tile.HasTile && tile.TileType == ModContent.TileType<CraftingCore>();
        }

        public override int Hook_AfterPlacement(int i, int j, int type, int style, int direction, int alternate)
        {
            if (Main.netMode == Terraria.ID.NetmodeID.MultiplayerClient)
            {
                int width = 2;
                int height = 2;
                NetMessage.SendTileSquare(Main.myPlayer, i, j, width, height);
                NetMessage.SendData(Terraria.ID.MessageID.TileEntityPlacement, number: i, number2: j, number3: Type);
                return -1;
            }

            int placedEntity = Place(i, j);
            if (TileEntity.ByID.TryGetValue(placedEntity, out var entity) && entity is CraftingCoreEntity cce)
                cce.InitializeSlots();

            return placedEntity;
        }

        public void EnsureSlotsInitialized() => InitializeSlots();

        private void InitializeSlots()
        {
            for (int i = 0; i < StationSlotCount; i++)
            {
                if (StationSlots[i] == null)
                {
                    StationSlots[i] = new Item();
                    StationSlots[i].TurnToAir();
                }
            }
        }

        /// <summary>
        /// Get all tile types that the inserted crafting station items would provide.
        /// Items that place tiles (createTile >= 0) count as providing that tile type
        /// as a crafting station.
        /// </summary>
        public HashSet<int> GetAvailableTileTypes()
        {
            var tileTypes = new HashSet<int>();
            InitializeSlots();

            for (int i = 0; i < StationSlotCount; i++)
            {
                if (StationSlots[i] != null && !StationSlots[i].IsAir && StationSlots[i].createTile >= 0)
                {
                    tileTypes.Add(StationSlots[i].createTile);
                }
            }

            return tileTypes;
        }

        /// <summary>
        /// Check if a specific item can be inserted as a crafting station.
        /// Only items that place tiles are valid (they represent crafting stations).
        /// </summary>
        public static bool IsValidStation(Item item)
        {
            return item != null && !item.IsAir && item.createTile >= 0;
        }

        /// <summary>
        /// Try to insert a station into the first available slot.
        /// </summary>
        public bool InsertStation(Item stationItem, int slot = -1)
        {
            if (!IsValidStation(stationItem))
                return false;

            InitializeSlots();

            if (slot >= 0 && slot < StationSlotCount)
            {
                if (StationSlots[slot].IsAir)
                {
                    StationSlots[slot] = stationItem.Clone();
                    return true;
                }
                return false;
            }

            for (int i = 0; i < StationSlotCount; i++)
            {
                if (StationSlots[i].IsAir)
                {
                    StationSlots[i] = stationItem.Clone();
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Remove a station from a specific slot.
        /// </summary>
        public Item RemoveStation(int slot)
        {
            InitializeSlots();

            if (slot < 0 || slot >= StationSlotCount || StationSlots[slot].IsAir)
                return new Item();

            var removed = StationSlots[slot].Clone();
            StationSlots[slot].TurnToAir();
            return removed;
        }

        /// <summary>
        /// Drop all stations when the block is destroyed.
        /// </summary>
        public void DropStations(int x, int y)
        {
            InitializeSlots();
            for (int i = 0; i < StationSlotCount; i++)
            {
                if (!StationSlots[i].IsAir)
                {
                    Item.NewItem(new EntitySource_TileBreak(x, y), x * 16, y * 16, 32, 32, StationSlots[i].type, StationSlots[i].stack, false, StationSlots[i].prefix);
                    StationSlots[i].TurnToAir();
                }
            }
        }

        public void OpenStationUI(Player player)
        {
            var uiSystem = ModContent.GetInstance<CraftingCoreUISystem>();
            uiSystem?.OpenCraftingCore(this);
        }

        public override void SaveData(TagCompound tag)
        {
            InitializeSlots();
            var stationTags = new List<TagCompound>();
            for (int i = 0; i < StationSlotCount; i++)
            {
                stationTags.Add(ItemIO.Save(StationSlots[i]));
            }
            tag["stations"] = stationTags;
        }

        public override void LoadData(TagCompound tag)
        {
            InitializeSlots();
            if (tag.ContainsKey("stations"))
            {
                var stationTags = tag.GetList<TagCompound>("stations");
                for (int i = 0; i < StationSlotCount && i < stationTags.Count; i++)
                {
                    StationSlots[i] = ItemIO.Load(stationTags[i]);
                }
            }
        }

        public override void NetSend(BinaryWriter writer)
        {
            InitializeSlots();
            for (int i = 0; i < StationSlotCount; i++)
            {
                ItemIO.Send(StationSlots[i], writer, true);
            }
        }

        public override void NetReceive(BinaryReader reader)
        {
            InitializeSlots();
            for (int i = 0; i < StationSlotCount; i++)
            {
                StationSlots[i] = ItemIO.Receive(reader, true);
            }
        }

        public static CraftingCoreEntity FindEntity(int i, int j)
        {
            var tile = Main.tile[i, j];
            if (!tile.HasTile)
                return null;

            var tileData = TileObjectData.GetTileData(tile);
            if (tileData == null)
                return null;

            int frameX = tile.TileFrameX / 18 % tileData.Width;
            int frameY = tile.TileFrameY / 18 % tileData.Height;
            int topLeftX = i - frameX;
            int topLeftY = j - frameY;

            var key = new Point16(topLeftX + tileData.Origin.X, topLeftY + tileData.Origin.Y);
            if (TileEntity.ByPosition.TryGetValue(key, out var entity) && entity is CraftingCoreEntity cce)
                return cce;

            return null;
        }
    }
}
