using Terraria.ModLoader;

namespace TerraStorage
{
    public class TerraStorage : Mod
    {
        public override void HandlePacket(System.IO.BinaryReader reader, int whoAmI)
        {
            Systems.NetworkHandler.HandlePacket(this, reader, whoAmI);
        }
    }
}
