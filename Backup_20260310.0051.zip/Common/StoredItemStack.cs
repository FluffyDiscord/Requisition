using Terraria;
using Terraria.ModLoader.IO;

namespace TerraStorage.Common
{
    public class StoredItemStack
    {
        public int ItemType { get; set; }
        public int Stack { get; set; }
        public int PrefixId { get; set; }
        public long InsertionOrder { get; set; }

        public StoredItemStack() { }

        public StoredItemStack(Item item)
        {
            ItemType = item.type;
            Stack = item.stack;
            PrefixId = item.prefix;
        }

        public Item ToItem()
        {
            var item = new Item();
            item.SetDefaults(ItemType);
            item.stack = Stack;
            item.Prefix(PrefixId);
            return item;
        }

        public TagCompound Save()
        {
            return new TagCompound
            {
                ["type"] = ItemType,
                ["stack"] = Stack,
                ["prefix"] = PrefixId,
                ["order"] = InsertionOrder
            };
        }

        public static StoredItemStack Load(TagCompound tag)
        {
            return new StoredItemStack
            {
                ItemType = tag.GetInt("type"),
                Stack = tag.GetInt("stack"),
                PrefixId = tag.GetInt("prefix"),
                InsertionOrder = tag.ContainsKey("order") ? tag.GetLong("order") : 0
            };
        }

        /// <summary>
        /// Returns true if this stack can merge with another (same type and prefix).
        /// </summary>
        public bool CanMergeWith(StoredItemStack other)
        {
            return ItemType == other.ItemType && PrefixId == other.PrefixId;
        }

        /// <summary>
        /// Returns true if this stack matches the given item type and prefix.
        /// </summary>
        public bool Matches(int itemType, int prefixId = -1)
        {
            return ItemType == itemType && (prefixId == -1 || PrefixId == prefixId);
        }
    }
}
