using System;
using System.Collections.Generic;
using System.Linq;
using Terraria;
using Terraria.ModLoader.IO;

namespace TerraStorage.Common
{
    public class DiskData
    {
        public Guid DiskId { get; set; }
        public DiskTier Tier { get; set; }
        public List<StoredItemStack> Items { get; set; } = new();

        public int MaxStacks => Tier.GetCapacity();
        public int UsedStacks => Items.Count;
        public bool IsFull => UsedStacks >= MaxStacks;

        /// <summary>
        /// Try to insert an item into this disk. Returns the leftover count (0 if fully inserted).
        /// </summary>
        public int InsertItem(Item item, long insertionOrder = 0)
        {
            if (item == null || item.IsAir)
                return 0;

            int remaining = item.stack;

            // Try to merge with existing stacks first
            foreach (var stored in Items)
            {
                if (stored.Matches(item.type, item.prefix) && stored.Stack < item.maxStack)
                {
                    int canAdd = Math.Min(remaining, item.maxStack - stored.Stack);
                    stored.Stack += canAdd;
                    if (insertionOrder > 0)
                        stored.InsertionOrder = insertionOrder;
                    remaining -= canAdd;
                    if (remaining <= 0)
                        return 0;
                }
            }

            // Add new stacks
            while (remaining > 0 && !IsFull)
            {
                int stackSize = Math.Min(remaining, item.maxStack);
                Items.Add(new StoredItemStack
                {
                    ItemType = item.type,
                    Stack = stackSize,
                    PrefixId = item.prefix,
                    InsertionOrder = insertionOrder
                });
                remaining -= stackSize;
            }

            return remaining;
        }

        /// <summary>
        /// Extract up to 'count' of the given item type. Returns the items extracted.
        /// </summary>
        public Item ExtractItem(int itemType, int count, int prefixId = -1)
        {
            int extracted = 0;
            var toRemove = new List<StoredItemStack>();

            foreach (var stored in Items)
            {
                if (!stored.Matches(itemType, prefixId))
                    continue;

                int canTake = Math.Min(count - extracted, stored.Stack);
                stored.Stack -= canTake;
                extracted += canTake;

                if (stored.Stack <= 0)
                    toRemove.Add(stored);

                if (extracted >= count)
                    break;
            }

            foreach (var r in toRemove)
                Items.Remove(r);

            if (extracted == 0)
                return new Item();

            var result = new Item();
            result.SetDefaults(itemType);
            result.stack = extracted;
            if (prefixId > 0)
                result.Prefix(prefixId);
            return result;
        }

        /// <summary>
        /// Count how many of a given item type are stored.
        /// </summary>
        public int CountItem(int itemType, int prefixId = -1)
        {
            return Items.Where(s => s.Matches(itemType, prefixId)).Sum(s => s.Stack);
        }

        public TagCompound Save()
        {
            return new TagCompound
            {
                ["guid"] = DiskId.ToByteArray(),
                ["tier"] = (int)Tier,
                ["items"] = Items.Select(i => i.Save()).ToList()
            };
        }

        public static DiskData Load(TagCompound tag)
        {
            var data = new DiskData
            {
                DiskId = new Guid(tag.GetByteArray("guid")),
                Tier = (DiskTier)tag.GetInt("tier")
            };

            if (tag.ContainsKey("items"))
            {
                var itemTags = tag.GetList<TagCompound>("items");
                data.Items = itemTags.Select(StoredItemStack.Load).ToList();
            }

            return data;
        }
    }
}
