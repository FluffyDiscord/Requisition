using System;
using System.Collections.Generic;
using System.Linq;
using Terraria;
using TerraStorage.Systems;

namespace TerraStorage.Helpers
{
    public class CraftingStep
    {
        public Recipe Recipe { get; set; }
        public int CraftCount { get; set; }
        public Dictionary<int, int> Consumed { get; set; } = new();
        public int ProducedType { get; set; }
        public int ProducedCount { get; set; }
        public List<int> RequiredStations { get; set; } = new();
    }

    public class CraftingPlan
    {
        public List<CraftingStep> Steps { get; set; } = new();
        public Dictionary<int, int> BaseMaterialsRequired { get; set; } = new();
        public Dictionary<int, int> BaseMaterialsMissing { get; set; } = new();
        public HashSet<int> RequiredStations { get; set; } = new();
        public HashSet<int> MissingStations { get; set; } = new();
        public bool IsFeasible { get; set; }
        public int FinalItemType { get; set; }
        public int FinalItemCount { get; set; }
    }

    public static class RecipeResolver
    {
        private const int MaxDepth = 10;

        // Cache for tile name lookups (populated lazily)
        private static readonly Dictionary<int, string> _tileNameCache = new();

        /// <summary>
        /// Resolve a recipe recursively, determining what base materials are needed
        /// and what intermediate crafting steps must be performed.
        /// Checks crafting station requirements against available stations.
        /// </summary>
        public static CraftingPlan Resolve(int targetItemType, int quantity, IEnumerable<Guid> diskIds, HashSet<int> availableStations)
        {
            var available = GetAvailableItems(diskIds);
            var plan = new CraftingPlan
            {
                FinalItemType = targetItemType,
                FinalItemCount = quantity
            };

            var resolving = new HashSet<int>(); // cycle detection
            bool feasible = ResolveRecursive(targetItemType, quantity, available, plan.Steps, resolving, 0,
                availableStations);

            // Collect required stations from successful steps only
            foreach (var step in plan.Steps)
            {
                foreach (int s in step.RequiredStations)
                    plan.RequiredStations.Add(s);
            }

            // Determine which stations are missing
            foreach (int stationType in plan.RequiredStations)
            {
                if (!availableStations.Contains(stationType))
                    plan.MissingStations.Add(stationType);
            }

            plan.IsFeasible = feasible && plan.MissingStations.Count == 0;

            // Calculate base materials
            CalculateBaseMaterials(plan, diskIds);

            return plan;
        }

        /// <summary>
        /// Get the display name for a tile type (for UI display of station requirements).
        /// Caches results for performance.
        /// </summary>
        public static string GetTileName(int tileType)
        {
            if (_tileNameCache.TryGetValue(tileType, out string cached))
                return cached;

            // Try to find an item that places this tile
            for (int i = 1; i < Terraria.ID.ItemID.Count; i++)
            {
                var tempItem = new Item();
                tempItem.SetDefaults(i);
                if (tempItem.createTile == tileType)
                {
                    _tileNameCache[tileType] = tempItem.Name;
                    return tempItem.Name;
                }
            }

            string fallback = $"Tile #{tileType}";
            _tileNameCache[tileType] = fallback;
            return fallback;
        }

        /// <summary>
        /// Get all available recipes that can be crafted with items in storage.
        /// Filters by available crafting stations.
        /// </summary>
        public static List<Recipe> GetAvailableRecipes(IEnumerable<Guid> diskIds, HashSet<int> availableStations)
        {
            var available = GetAvailableItems(diskIds);
            var results = new List<Recipe>();

            for (int i = 0; i < Recipe.numRecipes; i++)
            {
                var recipe = Main.recipe[i];
                if (recipe?.createItem == null || recipe.createItem.type <= 0)
                    continue;

                // Check crafting station requirements
                bool stationsMet = true;
                foreach (int tileType in recipe.requiredTile)
                {
                    if (tileType >= 0 && !availableStations.Contains(tileType))
                    {
                        stationsMet = false;
                        break;
                    }
                }
                if (!stationsMet)
                    continue;

                // Check ingredient availability
                bool canCraft = true;
                foreach (var ingredient in recipe.requiredItem)
                {
                    if (ingredient.type <= 0)
                        continue;

                    int needed = ingredient.stack;
                    bool found = false;

                    if (available.TryGetValue(ingredient.type, out int have) && have >= needed)
                        found = true;

                    // Check recipe groups
                    if (!found)
                    {
                        foreach (int groupId in recipe.acceptedGroups)
                        {
                            var group = RecipeGroup.recipeGroups[groupId];
                            if (group.ContainsItem(ingredient.type))
                            {
                                foreach (int validItem in group.ValidItems)
                                {
                                    if (available.TryGetValue(validItem, out int groupHave) && groupHave >= needed)
                                    {
                                        found = true;
                                        break;
                                    }
                                }
                            }
                            if (found)
                                break;
                        }
                    }

                    if (!found)
                    {
                        canCraft = false;
                        break;
                    }
                }

                if (canCraft)
                    results.Add(recipe);
            }

            return results;
        }

        /// <summary>
        /// Get all recipes. Returns (recipe, canCraft) where canCraft is true only if
        /// both station requirements AND ingredient requirements are met.
        /// </summary>
        public static List<(Recipe recipe, bool canCraft)> GetAllRecipesWithStations(
            IEnumerable<Guid> diskIds, HashSet<int> availableStations)
        {
            var available = GetAvailableItems(diskIds);
            var results = new List<(Recipe, bool)>();

            for (int i = 0; i < Recipe.numRecipes; i++)
            {
                var recipe = Main.recipe[i];
                if (recipe?.createItem == null || recipe.createItem.type <= 0)
                    continue;

                // Check crafting station requirements
                bool stationsMet = true;
                foreach (int tileType in recipe.requiredTile)
                {
                    if (tileType >= 0 && !availableStations.Contains(tileType))
                    {
                        stationsMet = false;
                        break;
                    }
                }

                // Check ingredient availability
                bool ingredientsMet = true;
                foreach (var ingredient in recipe.requiredItem)
                {
                    if (ingredient.type <= 0)
                        continue;

                    int needed = ingredient.stack;
                    bool found = false;

                    if (available.TryGetValue(ingredient.type, out int have) && have >= needed)
                        found = true;

                    if (!found)
                    {
                        foreach (int groupId in recipe.acceptedGroups)
                        {
                            var group = RecipeGroup.recipeGroups[groupId];
                            if (group.ContainsItem(ingredient.type))
                            {
                                foreach (int validItem in group.ValidItems)
                                {
                                    if (available.TryGetValue(validItem, out int groupHave) && groupHave >= needed)
                                    {
                                        found = true;
                                        break;
                                    }
                                }
                            }
                            if (found)
                                break;
                        }
                    }

                    if (!found)
                    {
                        ingredientsMet = false;
                        break;
                    }
                }

                results.Add((recipe, stationsMet && ingredientsMet));
            }

            return results;
        }

        /// <summary>
        /// Get the item type that places a given tile type. Returns -1 if not found.
        /// Cached for performance.
        /// </summary>
        private static readonly Dictionary<int, int> _tileToItemCache = new();
        public static int GetTileItemType(int tileType)
        {
            if (_tileToItemCache.TryGetValue(tileType, out int itemType))
                return itemType;

            for (int i = 1; i < Terraria.ID.ItemID.Count; i++)
            {
                var tempItem = new Item();
                tempItem.SetDefaults(i);
                if (tempItem.createTile == tileType)
                {
                    _tileToItemCache[tileType] = i;
                    return i;
                }
            }

            _tileToItemCache[tileType] = -1;
            return -1;
        }

        private static bool ResolveRecursive(int itemType, int needed, Dictionary<int, int> available,
            List<CraftingStep> steps, HashSet<int> resolving, int depth,
            HashSet<int> availableStations)
        {
            if (depth > MaxDepth)
                return false;

            // Check if we already have enough
            if (available.TryGetValue(itemType, out int have) && have >= needed)
            {
                available[itemType] -= needed;
                return true;
            }

            // Consume what we have
            int deficit = needed;
            if (have > 0)
            {
                deficit -= have;
                available[itemType] = 0;
            }

            // Cycle detection
            if (!resolving.Add(itemType))
                return false;

            var cache = RecipeCacheSystem.Instance;
            var recipes = cache.GetRecipesFor(itemType);

            foreach (var recipe in recipes)
            {
                // Collect station requirements for this recipe
                var stepStations = new List<int>();
                foreach (int tileType in recipe.requiredTile)
                {
                    if (tileType < 0)
                        continue;
                    stepStations.Add(tileType);
                }

                int craftsNeeded = (int)Math.Ceiling((double)deficit / recipe.createItem.stack);

                // Try to resolve all ingredients
                var availBackup = new Dictionary<int, int>(available);
                var tempSteps = new List<CraftingStep>();
                bool allResolved = true;
                var consumed = new Dictionary<int, int>();

                foreach (var ingredient in recipe.requiredItem)
                {
                    if (ingredient.type <= 0)
                        continue;

                    int ingredientNeeded = ingredient.stack * craftsNeeded;
                    consumed[ingredient.type] = ingredientNeeded;

                    if (!ResolveRecursive(ingredient.type, ingredientNeeded, available, tempSteps, resolving, depth + 1,
                        availableStations))
                    {
                        allResolved = false;
                        foreach (var kvp in availBackup)
                            available[kvp.Key] = kvp.Value;
                        break;
                    }
                }

                if (allResolved)
                {
                    steps.AddRange(tempSteps);

                    int produced = craftsNeeded * recipe.createItem.stack;
                    steps.Add(new CraftingStep
                    {
                        Recipe = recipe,
                        CraftCount = craftsNeeded,
                        Consumed = consumed,
                        ProducedType = itemType,
                        ProducedCount = produced,
                        RequiredStations = stepStations
                    });

                    int excess = produced - deficit;
                    if (excess > 0)
                    {
                        if (!available.ContainsKey(itemType))
                            available[itemType] = 0;
                        available[itemType] += excess;
                    }

                    resolving.Remove(itemType);
                    return true;
                }
            }

            resolving.Remove(itemType);
            return false;
        }

        private static Dictionary<int, int> GetAvailableItems(IEnumerable<Guid> diskIds)
        {
            var items = new Dictionary<int, int>();
            var consolidated = StorageWorldSystem.Instance.GetConsolidatedItems(diskIds);

            foreach (var ci in consolidated)
            {
                if (!items.ContainsKey(ci.ItemType))
                    items[ci.ItemType] = 0;
                items[ci.ItemType] += ci.TotalCount;
            }

            // Include player inventory
            var player = Main.LocalPlayer;
            for (int i = 0; i < 50; i++)
            {
                var inv = player.inventory[i];
                if (inv == null || inv.IsAir)
                    continue;
                if (!items.ContainsKey(inv.type))
                    items[inv.type] = 0;
                items[inv.type] += inv.stack;
            }

            return items;
        }

        private static void CalculateBaseMaterials(CraftingPlan plan, IEnumerable<Guid> diskIds)
        {
            var produced = new Dictionary<int, int>();
            var consumed = new Dictionary<int, int>();

            foreach (var step in plan.Steps)
            {
                foreach (var kvp in step.Consumed)
                {
                    if (!consumed.ContainsKey(kvp.Key))
                        consumed[kvp.Key] = 0;
                    consumed[kvp.Key] += kvp.Value;
                }

                if (!produced.ContainsKey(step.ProducedType))
                    produced[step.ProducedType] = 0;
                produced[step.ProducedType] += step.ProducedCount;
            }

            foreach (var kvp in consumed)
            {
                produced.TryGetValue(kvp.Key, out int prod);
                int netRequired = kvp.Value - prod;
                if (netRequired > 0)
                {
                    plan.BaseMaterialsRequired[kvp.Key] = netRequired;

                    int inStorage = StorageWorldSystem.Instance.CountItem(diskIds, kvp.Key);
                    int inInventory = CountPlayerItem(kvp.Key);
                    int totalAvailable = inStorage + inInventory;
                    if (totalAvailable < netRequired)
                        plan.BaseMaterialsMissing[kvp.Key] = netRequired - totalAvailable;
                }
            }
        }

        private static int CountPlayerItem(int itemType)
        {
            int count = 0;
            var player = Main.LocalPlayer;
            for (int i = 0; i < 50; i++)
            {
                if (player.inventory[i] != null && !player.inventory[i].IsAir && player.inventory[i].type == itemType)
                    count += player.inventory[i].stack;
            }
            return count;
        }

        /// <summary>
        /// Extract items from storage first, then from player inventory for any remainder.
        /// </summary>
        private static void ExtractFromBoth(List<Guid> diskList, int itemType, int amount)
        {
            // Try storage first
            var extracted = StorageWorldSystem.Instance.ExtractItem(diskList, itemType, amount);
            int got = extracted.IsAir ? 0 : extracted.stack;
            int remaining = amount - got;

            // Take remainder from player inventory
            if (remaining > 0)
            {
                var player = Main.LocalPlayer;
                for (int i = 0; i < 50 && remaining > 0; i++)
                {
                    var inv = player.inventory[i];
                    if (inv == null || inv.IsAir || inv.type != itemType)
                        continue;

                    int take = Math.Min(inv.stack, remaining);
                    inv.stack -= take;
                    remaining -= take;
                    if (inv.stack <= 0)
                        inv.TurnToAir();
                }
            }
        }

        /// <summary>
        /// Execute a crafting plan, consuming items from storage and player inventory,
        /// producing the result back into storage.
        /// </summary>
        public static Item ExecutePlan(CraftingPlan plan, IEnumerable<Guid> diskIds)
        {
            if (!plan.IsFeasible)
                return new Item();

            var diskList = diskIds.ToList();

            foreach (var step in plan.Steps)
            {
                foreach (var kvp in step.Consumed)
                {
                    ExtractFromBoth(diskList, kvp.Key, kvp.Value);
                }

                var produced = new Item();
                produced.SetDefaults(step.ProducedType);
                produced.stack = step.ProducedCount;
                StorageWorldSystem.Instance.InsertItem(diskList, produced);
            }

            // Extract the final item from storage and return it (caller will insert it back)
            return StorageWorldSystem.Instance.ExtractItem(diskList, plan.FinalItemType, plan.FinalItemCount);
        }
    }
}
