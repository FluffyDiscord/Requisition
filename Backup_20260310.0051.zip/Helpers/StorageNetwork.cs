using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using TerraStorage.Content.Tiles;

namespace TerraStorage.Helpers
{
    public static class StorageNetwork
    {
        public const int SearchRadius = 30;

        /// <summary>
        /// Find all StorageBlockEntity instances within radius of the given tile position.
        /// </summary>
        public static List<StorageBlockEntity> FindConnectedStorageBlocks(Point16 terminalPosition)
        {
            var results = new List<StorageBlockEntity>();

            foreach (var kvp in TileEntity.ByID)
            {
                if (kvp.Value is StorageBlockEntity storageEntity)
                {
                    float dist = Vector2.Distance(
                        new Vector2(terminalPosition.X, terminalPosition.Y),
                        new Vector2(storageEntity.Position.X, storageEntity.Position.Y)
                    );

                    if (dist <= SearchRadius)
                        results.Add(storageEntity);
                }
            }

            return results;
        }

        /// <summary>
        /// Find all CraftingCoreEntity instances within radius of the given tile position.
        /// </summary>
        public static List<CraftingCoreEntity> FindConnectedCraftingCores(Point16 terminalPosition)
        {
            var results = new List<CraftingCoreEntity>();

            foreach (var kvp in TileEntity.ByID)
            {
                if (kvp.Value is CraftingCoreEntity craftingCore)
                {
                    float dist = Vector2.Distance(
                        new Vector2(terminalPosition.X, terminalPosition.Y),
                        new Vector2(craftingCore.Position.X, craftingCore.Position.Y)
                    );

                    if (dist <= SearchRadius)
                        results.Add(craftingCore);
                }
            }

            return results;
        }

        /// <summary>
        /// Get all disk IDs from all storage blocks connected to a terminal position.
        /// </summary>
        public static List<Guid> GetAllConnectedDiskIds(Point16 terminalPosition)
        {
            var diskIds = new List<Guid>();
            var blocks = FindConnectedStorageBlocks(terminalPosition);

            foreach (var block in blocks)
            {
                diskIds.AddRange(block.GetInsertedDiskIds());
            }

            return diskIds;
        }

        /// <summary>
        /// Get all tile types available as crafting stations from connected Crafting Cores.
        /// </summary>
        public static HashSet<int> GetAllAvailableStations(Point16 terminalPosition)
        {
            var stations = new HashSet<int>();
            var cores = FindConnectedCraftingCores(terminalPosition);

            foreach (var core in cores)
            {
                stations.UnionWith(core.GetAvailableTileTypes());
            }

            return stations;
        }
    }
}
