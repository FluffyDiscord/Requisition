using Terraria;
using Terraria.ModLoader.IO;

namespace TerraStorage.Helpers
{
    public static class ItemSerializer
    {
        public static TagCompound SaveItem(Item item)
        {
            if (item == null || item.IsAir)
                return new TagCompound { ["isAir"] = true };

            return new TagCompound
            {
                ["type"] = item.type,
                ["stack"] = item.stack,
                ["prefix"] = (int)item.prefix,
                ["isAir"] = false
            };
        }

        public static Item LoadItem(TagCompound tag)
        {
            if (tag == null || tag.GetBool("isAir"))
                return new Item();

            var item = new Item();
            item.SetDefaults(tag.GetInt("type"));
            item.stack = tag.GetInt("stack");
            item.Prefix(tag.GetInt("prefix"));
            return item;
        }

        public static TagCompound[] SaveItemArray(Item[] items)
        {
            var tags = new TagCompound[items.Length];
            for (int i = 0; i < items.Length; i++)
                tags[i] = SaveItem(items[i]);
            return tags;
        }

        public static Item[] LoadItemArray(TagCompound[] tags, int length)
        {
            var items = new Item[length];
            for (int i = 0; i < length; i++)
            {
                if (i < tags.Length)
                    items[i] = LoadItem(tags[i]);
                else
                {
                    items[i] = new Item();
                    items[i].TurnToAir();
                }
            }
            return items;
        }
    }
}
